<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @package    Floating_Contact_Button
 * @subpackage Floating_Contact_Button/public
 */
class Floating_Contact_Button_Public {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        // Only load on front-end
        if (is_admin()) {
            return;
        }

        // Font Awesome - using both methods to ensure compatibility
        wp_enqueue_style('font-awesome-5', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css', array(), '5.15.4');
        wp_enqueue_style('font-awesome-4', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array(), '4.7.0');
        
        // Plugin front-end CSS
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/fcb-public.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        // Only load on front-end
        if (is_admin()) {
            return;
        }
        
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/fcb-public.js', array('jquery'), $this->version, true);
    }

    /**
     * Display the floating contact buttons
     */
    public function display_floating_buttons() {
        // Get buttons data
        $buttons = get_option('fcb_buttons', array());
        
        // If no buttons, exit
        if (empty($buttons)) {
            return;
        }
        
        // Get placement settings
        $placement = get_option('fcb_placement', array(
            'position' => 'bottom-right',
            'visibility' => 'all',
            'specific_pages' => array(),
            'spacing' => '20',
        ));
        
        // Check visibility settings
        if (!$this->should_display_buttons($placement)) {
            return;
        }
        
        // Get design settings
        $design = get_option('fcb_design', array(
            'button_shape' => 'round',
            'shadow' => 'on',
            'icon_size' => 'medium',
            'button_size' => 'medium',
        ));
        
        // Sort buttons by order
        usort($buttons, function($a, $b) {
            return $a['order'] - $b['order'];
        });
        
        // Pass data to template
        $data = array(
            'buttons' => $buttons,
            'placement' => $placement,
            'design' => $design,
        );
        
        // Include template
        include_once('partials/fcb-public-display.php');
    }

    /**
     * Check if buttons should be displayed
     */
    private function should_display_buttons($placement) {
        // Always show on all pages
        if ($placement['visibility'] === 'all') {
            return true;
        }
        
        // Show only on homepage
        if ($placement['visibility'] === 'homepage' && is_front_page()) {
            return true;
        }
        
        // Show on specific pages
        if ($placement['visibility'] === 'specific' && !empty($placement['specific_pages'])) {
            $current_id = get_the_ID();
            if (in_array($current_id, $placement['specific_pages'])) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Generate URL based on button type and value
     */
    public function get_button_url($button) {
        $value = isset($button['value']) ? $button['value'] : '';
        
        // Default to # if value is empty
        if (empty($value) && $button['type'] !== 'whatsapp') {
            return '#';
        }
        
        switch ($button['type']) {
            case 'whatsapp':
                // Use API URL for WhatsApp, ensure a valid value or default
                $phone = preg_replace('/[^0-9]/', '', $value);
                return !empty($phone) ? 'https://api.whatsapp.com/send?phone=' . $phone : 'https://api.whatsapp.com/';
                
            case 'email':
                return 'mailto:' . esc_attr($value);
                
            case 'phone':
                return 'tel:' . esc_attr($value);
                
            case 'messenger':
                // If it's a full URL, use it directly
                if (filter_var($value, FILTER_VALIDATE_URL)) {
                    return esc_url($value);
                }
                // Otherwise, assume it's a username
                return 'https://m.me/' . esc_attr($value);
                
            case 'telegram':
                return 'https://t.me/' . esc_attr($value);
                
            case 'custom':
                return esc_url($value);
                
            default:
                return '#';
        }
    }
}
