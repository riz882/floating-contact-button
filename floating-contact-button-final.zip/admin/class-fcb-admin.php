<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @package    Floating_Contact_Button
 * @subpackage Floating_Contact_Button/admin
 */
class Floating_Contact_Button_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * The current active tab in the admin panel.
     */
    private $active_tab;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'buttons_manager';
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        // Only load on our plugin page
        if (!$this->is_plugin_page()) {
            return;
        }

        // WordPress color picker
        wp_enqueue_style('wp-color-picker');
        
        // Font Awesome
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css', array(), '5.15.4');
        
        // Plugin admin CSS
        wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/fcb-admin.css', array(), $this->version, 'all');
        
        // Enhancements CSS - for country selector and range slider
        wp_enqueue_style($this->plugin_name . '-enhancements', plugin_dir_url(__FILE__) . 'css/fcb-admin-enhancements.css', array(), $this->version, 'all');
        
        // jQuery UI CSS for the slider
        wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css', array(), '1.13.2');
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        // Only load on our plugin page
        if (!$this->is_plugin_page()) {
            return;
        }

        // WordPress color picker & media uploader
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_media();
        
        // jQuery UI for sortable and slider functionality
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_script('jquery-ui-slider');
        
        // Plugin admin JS
        wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/fcb-admin.js', array('jquery', 'wp-color-picker', 'jquery-ui-sortable'), $this->version, false);
        
        // Enhancement scripts for country selector and range slider
        wp_enqueue_script($this->plugin_name . '-enhancements', plugin_dir_url(__FILE__) . 'js/fcb-admin-enhancements.js', array('jquery', 'jquery-ui-slider'), $this->version, false);
        
        // Localize script
        wp_localize_script($this->plugin_name, 'fcb_admin_vars', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('fcb_nonce'),
            'preview_nonce' => wp_create_nonce('fcb_preview_nonce'),
        ));
    }

    /**
     * Check if current page is our plugin page
     */
    private function is_plugin_page() {
        $screen = get_current_screen();
        if ($screen && strpos($screen->id, 'floating-contact-button') !== false) {
            return true;
        }
        return false;
    }

    /**
     * Add menu item for our plugin
     */
    public function add_plugin_admin_menu() {
        add_menu_page(
            __('Floating Contact Button', 'floating-contact-button'),
            __('Floating Contact', 'floating-contact-button'),
            'manage_options',
            $this->plugin_name,
            array($this, 'display_plugin_admin_page'),
            'dashicons-phone',
            81 // Position below Settings
        );
    }

    /**
     * Add settings action link to the plugins page.
     */
    public function add_action_links($links) {
        $settings_link = array(
            '<a href="' . admin_url('admin.php?page=' . $this->plugin_name) . '">' . __('Settings', 'floating-contact-button') . '</a>',
        );
        return array_merge($settings_link, $links);
    }

    /**
     * Render the settings page for this plugin.
     */
    public function display_plugin_admin_page() {
        include_once('partials/fcb-admin-display.php');
    }

    /**
     * Update options
     */
    public function options_update() {
        // If not a POST request or not our form, exit
        if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        if (!isset($_POST['fcb_form_submitted'])) {
            return;
        }

        // Verify the nonce before proceeding
        if (!isset($_POST['fcb_nonce']) || !wp_verify_nonce($_POST['fcb_nonce'], 'fcb_settings_nonce')) {
            add_settings_error(
                'fcb_messages',
                'fcb_message',
                __('Security verification failed.', 'floating-contact-button'),
                'error'
            );
            return;
        }

        // Check user permissions
        if (!current_user_can('manage_options')) {
            add_settings_error(
                'fcb_messages',
                'fcb_message',
                __('You do not have sufficient permissions to access this page.', 'floating-contact-button'),
                'error'
            );
            return;
        }

        // Process buttons data
        if (isset($_POST['fcb_form_tab']) && $_POST['fcb_form_tab'] === 'buttons_manager') {
            $this->save_buttons_data();
        }

        // Process placement data
        if (isset($_POST['fcb_form_tab']) && $_POST['fcb_form_tab'] === 'placement') {
            $this->save_placement_data();
        }

        // Process design data
        if (isset($_POST['fcb_form_tab']) && $_POST['fcb_form_tab'] === 'design') {
            $this->save_design_data();
        }

        add_settings_error(
            'fcb_messages',
            'fcb_message',
            __('Settings Saved', 'floating-contact-button'),
            'updated'
        );
    }

    /**
     * Save buttons data
     */
    private function save_buttons_data() {
        // Sanitize JSON data for buttons
        if (!empty($_POST['fcb_buttons_data'])) {
            $buttons_data = json_decode(stripslashes($_POST['fcb_buttons_data']), true);
            
            if (is_array($buttons_data)) {
                $sanitized_buttons = array();
                
                foreach ($buttons_data as $button) {
                    $sanitized_button = array(
                        'type' => sanitize_text_field($button['type']),
                        'value' => sanitize_text_field($button['value']),
                        'label' => sanitize_text_field($button['label']),
                        'icon' => sanitize_text_field($button['icon']),
                        'bg_color' => sanitize_hex_color($button['bg_color']),
                        'icon_color' => sanitize_hex_color($button['icon_color']),
                        'order' => intval($button['order']),
                    );
                    $sanitized_buttons[] = $sanitized_button;
                }
                
                update_option('fcb_buttons', $sanitized_buttons);
            }
        } else {
            // If no buttons, save empty array
            update_option('fcb_buttons', array());
        }
    }

    /**
     * Save placement data
     */
    private function save_placement_data() {
        $placement_data = array(
            'position' => sanitize_text_field($_POST['fcb_position']),
            'visibility' => sanitize_text_field($_POST['fcb_visibility']),
            'specific_pages' => array(),
            'spacing' => intval($_POST['fcb_spacing']),
        );

        // Process specific pages if available
        if (isset($_POST['fcb_specific_pages']) && is_array($_POST['fcb_specific_pages'])) {
            foreach ($_POST['fcb_specific_pages'] as $page_id) {
                $placement_data['specific_pages'][] = intval($page_id);
            }
        }

        update_option('fcb_placement', $placement_data);
    }

    /**
     * Save design data
     */
    private function save_design_data() {
        $design_data = array(
            // Main button settings
            'main_bg_color' => sanitize_hex_color($_POST['fcb_main_bg_color']),
            'main_icon_color' => sanitize_hex_color($_POST['fcb_main_icon_color']),
            'main_icon' => sanitize_text_field($_POST['fcb_main_icon']),
            
            // Contact buttons settings
            'button_shape' => sanitize_text_field($_POST['fcb_button_shape']),
            'shadow' => sanitize_text_field($_POST['fcb_shadow']),
            'icon_size' => sanitize_text_field($_POST['fcb_icon_size']),
            'button_size' => sanitize_text_field($_POST['fcb_button_size']),
            'animation_speed' => sanitize_text_field($_POST['fcb_animation_speed']),
        );

        update_option('fcb_design', $design_data);
    }

    /**
     * Get contact button types
     */
    public function get_button_types() {
        return array(
            'whatsapp' => array(
                'label' => __('WhatsApp', 'floating-contact-button'),
                'icon' => 'fab fa-whatsapp',
                'default_color' => '#25D366'
            ),
            'email' => array(
                'label' => __('Email', 'floating-contact-button'),
                'icon' => 'fas fa-envelope',
                'default_color' => '#FF5722'
            ),
            'phone' => array(
                'label' => __('Phone', 'floating-contact-button'),
                'icon' => 'fas fa-phone-alt',
                'default_color' => '#4CAF50'
            ),
            'messenger' => array(
                'label' => __('Facebook Messenger', 'floating-contact-button'),
                'icon' => 'fab fa-facebook-messenger',
                'default_color' => '#0084FF'
            ),
            'telegram' => array(
                'label' => __('Telegram', 'floating-contact-button'),
                'icon' => 'fab fa-telegram-plane',
                'default_color' => '#0088cc'
            ),
            'custom' => array(
                'label' => __('Custom URL', 'floating-contact-button'),
                'icon' => 'fas fa-link',
                'default_color' => '#2196F3'
            ),
        );
    }

    /**
     * Get Font Awesome icons for selection
     */
    public function get_fa_icons() {
        // Return a subset of commonly used icons
        return array(
            'fab fa-whatsapp' => 'WhatsApp',
            'fas fa-envelope' => 'Email',
            'fas fa-phone-alt' => 'Phone',
            'fab fa-facebook-messenger' => 'Messenger',
            'fab fa-telegram-plane' => 'Telegram',
            'fas fa-link' => 'Link',
            'fas fa-calendar' => 'Calendar',
            'fas fa-comments' => 'Comments',
            'fas fa-map-marker-alt' => 'Location',
            'fas fa-user' => 'User',
            'fas fa-shopping-cart' => 'Cart',
            'fas fa-info-circle' => 'Info',
            'fas fa-question-circle' => 'Help',
        );
    }
}
