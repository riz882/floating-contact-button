/**
 * Admin panel enhancements for the Floating Contact Button plugin.
 * Adds country selector for WhatsApp and range slider for spacing.
 */

(function($) {
    'use strict';

    /**
     * Initialize the WhatsApp country selector with IntlTelInput
     */
    function initWhatsAppCountrySelector() {
        // Apply to all existing WhatsApp input fields
        $('.fcb-button-type').each(function() {
            if ($(this).val() === 'whatsapp') {
                const valueInput = $(this).closest('.fcb-button-content').find('.fcb-button-value');
                if (!valueInput.hasClass('iti-enabled')) {
                    applyIntlTelInput(valueInput);
                }
            }
        });

        // Add listener for button type changes to apply/remove phone input
        $(document).on('change', '.fcb-button-type', function() {
            const valueInput = $(this).closest('.fcb-button-content').find('.fcb-button-value');
            
            // If changing to WhatsApp
            if ($(this).val() === 'whatsapp') {
                if (!valueInput.hasClass('iti-enabled')) {
                    applyIntlTelInput(valueInput);
                }
            } 
            // If changing from WhatsApp to something else
            else if (valueInput.hasClass('iti-enabled')) {
                // Get the actual value
                const number = valueInput.val();
                
                // Destroy the intlTelInput instance
                const iti = valueInput.data('iti');
                if (iti) {
                    iti.destroy();
                }
                
                // Remove classes and reset the input
                valueInput.removeClass('iti-enabled fcb-valid-input fcb-invalid-input');
                valueInput.parent().find('.fcb-validation-error').remove();
                valueInput.val(number);
            }
        });

        // Also handle new buttons being added
        $(document).on('fcb:buttonAdded', function(e, buttonElement) {
            const buttonType = $(buttonElement).find('.fcb-button-type');
            if (buttonType.val() === 'whatsapp') {
                const valueInput = $(buttonElement).find('.fcb-button-value');
                if (!valueInput.hasClass('iti-enabled')) {
                    applyIntlTelInput(valueInput);
                }
            }
        });
    }

    /**
     * Apply IntlTelInput to a specific input element
     */
    function applyIntlTelInput(inputElement) {
        // If IntlTelInput is not loaded yet, try to load it
        if (typeof window.intlTelInput !== 'function') {
            if (!$('script[src*="intl-tel-input"]').length) {
                // Load CSS
                $('head').append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css">');
                
                // Add custom CSS fixes
                $('head').append('<style>\
                    /* Fix dropdown position */\
                    .iti--container { \
                        position: fixed; \
                        top: 0; \
                        left: 0; \
                        bottom: 0; \
                        right: 0; \
                        background: rgba(0,0,0,0.7); \
                        z-index: 9999; \
                        padding: 20px; \
                        display: flex; \
                        align-items: center; \
                        justify-content: center; \
                    } \
                    .iti--container .iti__country-list { \
                        position: relative; \
                        width: 350px; \
                        max-width: 90%; \
                        max-height: 60vh; \
                        margin: 0 auto; \
                        border-radius: 5px; \
                        box-shadow: 0 0 15px rgba(0,0,0,0.3); \
                    } \
                    /* Fixed search box */\
                    .iti__search-container { \
                        position: sticky; \
                        top: 0; \
                        background-color: #fff; \
                        padding: 10px; \
                        border-bottom: 1px solid #ccc; \
                        z-index: 2; \
                    } \
                    .iti__search-input { \
                        width: 100%; \
                        padding: 8px; \
                        border: 1px solid #ddd; \
                        border-radius: 4px; \
                        font-size: 14px; \
                    } \
                    /* Add close button */ \
                    .iti__close-button { \
                        position: absolute; \
                        top: -10px; \
                        right: -10px; \
                        background: #fff; \
                        border: 1px solid #ccc; \
                        border-radius: 50%; \
                        width: 25px; \
                        height: 25px; \
                        text-align: center; \
                        line-height: 23px; \
                        font-size: 14px; \
                        font-weight: bold; \
                        cursor: pointer; \
                        box-shadow: 0px 0px 5px rgba(0,0,0,0.2); \
                    } \
                </style>');
                
                // Load scripts
                $.getScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js', function() {
                    $.getScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js', function() {
                        applyIntlTelInput(inputElement);
                    });
                });
            }
            return;
        }

        // Initialize intlTelInput with modal dropdown
        const phoneInput = inputElement[0];
        const iti = window.intlTelInput(phoneInput, {
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
            separateDialCode: true,
            initialCountry: "in",
            allowDropdown: true,
            formatOnDisplay: true,
            autoPlaceholder: "aggressive",
            nationalMode: false,
            excludeCountries: [],
            preferredCountries: [],
            // Use container for modal style dropdown
            dropdownContainer: document.body
        });

        // Store the instance
        $(phoneInput).data('iti', iti);
        $(phoneInput).addClass('iti-enabled');
        
        // Add search box and close button to country dropdown
        function enhanceCountryDropdown() {
            const countryList = $('.iti__country-list');
            if (countryList.length && !countryList.find('.iti__search-container').length) {
                // Add search box
                countryList.prepend(
                    '<div class="iti__search-container">' +
                    '<input type="text" class="iti__search-input" placeholder="Search for a country...">' +
                    '</div>'
                );
                
                // Add close button
                countryList.append('<div class="iti__close-button">×</div>');
                
                // Search functionality
                $('.iti__search-input').on('keyup', function() {
                    const searchText = $(this).val().toLowerCase();
                    $('.iti__country').each(function() {
                        const countryName = $(this).find('.iti__country-name').text().toLowerCase();
                        const countryCode = $(this).find('.iti__dial-code').text().toLowerCase();
                        if (countryName.indexOf(searchText) !== -1 || countryCode.indexOf(searchText) !== -1) {
                            $(this).show();
                        } else {
                            $(this).hide();
                        }
                    });
                });
                
                // Focus the search input
                $('.iti__search-input').focus();
                
                // Close button functionality
                $('.iti__close-button').on('click', function() {
                    $('.iti--container').remove();
                });
                
                // Close on click outside
                $('.iti--container').on('click', function(e) {
                    if ($(e.target).hasClass('iti--container')) {
                        $('.iti--container').remove();
                    }
                });
            }
        }
        
        // Watch for dropdown opening
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length) {
                    for (let i = 0; i < mutation.addedNodes.length; i++) {
                        const node = mutation.addedNodes[i];
                        if ($(node).hasClass('iti--container')) {
                            enhanceCountryDropdown();
                            return;
                        }
                    }
                }
            });
        });
        
        observer.observe(document.body, { childList: true });
        
        // Handle validation on input without interfering with dropdown
        $(phoneInput).on('input', function() {
            validatePhoneNumber($(this), iti);
        });

        // Also validate when country changes
        phoneInput.addEventListener('countrychange', function() {
            validatePhoneNumber($(phoneInput), iti);
        });

        // Format existing number if present
        if ($(phoneInput).val()) {
            // Small delay to ensure the plugin is fully initialized
            setTimeout(() => {
                const currentNumber = $(phoneInput).val();
                // Only process if it appears to be a number
                if (/^[0-9+\s()-]+$/.test(currentNumber)) {
                    try {
                        // Try to format the existing number
                        iti.setNumber(currentNumber);
                        validatePhoneNumber($(phoneInput), iti);
                    } catch (e) {
                        // If there's an error, keep the original input
                        console.log('Could not format existing number');
                    }
                }
            }, 500);
        }
    }

    /**
     * Validate phone number based on the selected country
     */
    function validatePhoneNumber($input, iti) {
        const errorMap = [
            "Invalid number",
            "Invalid country code",
            "Too short",
            "Too long",
            "Invalid number"
        ];

        if ($input.val().trim()) {
            if (iti.isValidNumber()) {
                $input.removeClass('fcb-invalid-input').addClass('fcb-valid-input');
                $input.parent().find('.fcb-validation-error').remove();
            } else {
                const errorCode = iti.getValidationError();
                const errorMsg = errorMap[errorCode] || "Invalid number";
                
                $input.removeClass('fcb-valid-input').addClass('fcb-invalid-input');
                
                // Show error message if it doesn't exist yet
                if (!$input.parent().find('.fcb-validation-error').length) {
                    $('<div class="fcb-validation-error">' + errorMsg + '</div>').insertAfter($input);
                } else {
                    $input.parent().find('.fcb-validation-error').text(errorMsg);
                }
            }
        } else {
            // Input is empty
            $input.removeClass('fcb-invalid-input fcb-valid-input');
            $input.parent().find('.fcb-validation-error').remove();
        }
    }

    /**
     * Initialize the spacing range slider
     */
    function initSpacingRangeSlider() {
        if ($('#fcb_spacing').length) {
            // Get the current value
            const currentValue = $('#fcb_spacing').val() || 20; // Default to 20px if not set
            
            // Remove any previous instances to avoid duplicates
            $('#fcb_spacing').parent('.fcb-form-row-spacing').find('.fcb-slider-container').remove();
            if ($('#fcb_spacing').parent().hasClass('fcb-form-row-spacing')) {
                $('#fcb_spacing').unwrap();
            }
            $('#fcb_spacing').removeClass('fcb-spacing-number-input');
            
            // Create the layout elements with proper structure
            const $formRow = $('<div class="fcb-form-row"></div>'); // Original label container
            const $spacingWrapper = $('<div class="fcb-form-row-spacing"></div>'); // Container for input and slider
            
            // Elements for the slider
            const $container = $('<div class="fcb-slider-container"></div>');
            const $sliderElement = $('<div class="fcb-spacing-slider"></div>');
            const $valueDisplay = $('<div class="fcb-slider-value">' + currentValue + 'px</div>');
            
            // Properly arrange everything
            $('#fcb_spacing').wrap($spacingWrapper);
            $container.append($sliderElement);
            $container.append($valueDisplay);
            $('.fcb-form-row-spacing').append($container);
            
            // Initialize jQuery UI slider
            $sliderElement.slider({
                min: 0,
                max: 100,
                value: currentValue,
                slide: function(event, ui) {
                    // Update both the original input and the value display
                    $('#fcb_spacing').val(ui.value);
                    $valueDisplay.text(ui.value + 'px');
                }
            });
            
            // Connect the number input to the slider
            $('#fcb_spacing').on('input', function() {
                const val = parseInt($(this).val(), 10);
                if (!isNaN(val)) {
                    $sliderElement.slider('value', val);
                    $valueDisplay.text(val + 'px');
                }
            });
            
            // Make sure the styling is applied
            $('#fcb_spacing').addClass('fcb-spacing-number-input');
        }
    }

    /**
     * Initialize enhancements when document is ready
     */
    $(document).ready(function() {
        // Only run on the plugin's admin page
        if ($('body.floating-contact-button_page_floating-contact-button').length || 
            $('body.toplevel_page_floating-contact-button').length) {
            
            // Load the IntlTelInput library dynamically
            if (!$('script[src*="intl-tel-input"]').length) {
                $('head').append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css">');
                $.getScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js', function() {
                    initWhatsAppCountrySelector();
                });
            } else {
                initWhatsAppCountrySelector();
            }
            
            // Initialize the spacing range slider
            initSpacingRangeSlider();
        }
    });
    
})(jQuery);