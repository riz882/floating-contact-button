<?php
/**
 * Design tab
 *
 * @package    Floating_Contact_Button
 * @subpackage Floating_Contact_Button/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get design settings
$design = get_option('fcb_design', array(
    'button_shape' => 'round',
    'shadow' => 'on',
    'icon_size' => 'medium',
    'button_size' => 'medium',
));
?>

<div class="fcb-columns">
    <div class="fcb-column fcb-column-70">
        <div class="fcb-section-title">
            <h3><?php _e('Design & Style Settings', 'floating-contact-button'); ?></h3>
            <p><?php _e('Customize the appearance of your floating contact buttons.', 'floating-contact-button'); ?></p>
        </div>
        
        <h4><?php _e('Main Button Settings', 'floating-contact-button'); ?></h4>
        
        <div class="fcb-form-row">
            <label for="fcb_main_bg_color"><?php _e('Main Button Color:', 'floating-contact-button'); ?></label>
            <input type="text" name="fcb_main_bg_color" id="fcb_main_bg_color" class="fcb-color-picker" 
                   value="<?php echo isset($design['main_bg_color']) ? esc_attr($design['main_bg_color']) : '#4A90E2'; ?>" 
                   data-default-color="#4A90E2">
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_main_icon_color"><?php _e('Main Button Icon Color:', 'floating-contact-button'); ?></label>
            <input type="text" name="fcb_main_icon_color" id="fcb_main_icon_color" class="fcb-color-picker" 
                   value="<?php echo isset($design['main_icon_color']) ? esc_attr($design['main_icon_color']) : '#FFFFFF'; ?>" 
                   data-default-color="#FFFFFF">
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_main_icon"><?php _e('Main Button Icon:', 'floating-contact-button'); ?></label>
            <select name="fcb_main_icon" id="fcb_main_icon">
                <option value="fas fa-comments" <?php selected(isset($design['main_icon']) ? $design['main_icon'] : 'fas fa-comments', 'fas fa-comments'); ?>><?php _e('Comments', 'floating-contact-button'); ?></option>
                <option value="fas fa-headset" <?php selected(isset($design['main_icon']) ? $design['main_icon'] : '', 'fas fa-headset'); ?>><?php _e('Headset', 'floating-contact-button'); ?></option>
                <option value="fas fa-envelope" <?php selected(isset($design['main_icon']) ? $design['main_icon'] : '', 'fas fa-envelope'); ?>><?php _e('Envelope', 'floating-contact-button'); ?></option>
                <option value="fas fa-phone" <?php selected(isset($design['main_icon']) ? $design['main_icon'] : '', 'fas fa-phone'); ?>><?php _e('Phone', 'floating-contact-button'); ?></option>
                <option value="fas fa-question-circle" <?php selected(isset($design['main_icon']) ? $design['main_icon'] : '', 'fas fa-question-circle'); ?>><?php _e('Question Circle', 'floating-contact-button'); ?></option>
                <option value="fas fa-info-circle" <?php selected(isset($design['main_icon']) ? $design['main_icon'] : '', 'fas fa-info-circle'); ?>><?php _e('Info Circle', 'floating-contact-button'); ?></option>
            </select>
        </div>
        
        <hr style="margin: 20px 0;">
        
        <h4><?php _e('Contact Buttons Settings', 'floating-contact-button'); ?></h4>
        
        <div class="fcb-form-row">
            <label for="fcb_button_shape"><?php _e('Button Shape:', 'floating-contact-button'); ?></label>
            <select name="fcb_button_shape" id="fcb_button_shape">
                <option value="round" <?php selected($design['button_shape'], 'round'); ?>><?php _e('Round', 'floating-contact-button'); ?></option>
                <option value="rounded-square" <?php selected($design['button_shape'], 'rounded-square'); ?>><?php _e('Rounded Square', 'floating-contact-button'); ?></option>
                <option value="pill" <?php selected($design['button_shape'], 'pill'); ?>><?php _e('Pill', 'floating-contact-button'); ?></option>
            </select>
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_shadow"><?php _e('Button Shadow:', 'floating-contact-button'); ?></label>
            <select name="fcb_shadow" id="fcb_shadow">
                <option value="on" <?php selected($design['shadow'], 'on'); ?>><?php _e('On', 'floating-contact-button'); ?></option>
                <option value="off" <?php selected($design['shadow'], 'off'); ?>><?php _e('Off', 'floating-contact-button'); ?></option>
            </select>
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_icon_size"><?php _e('Icon Size:', 'floating-contact-button'); ?></label>
            <select name="fcb_icon_size" id="fcb_icon_size">
                <option value="small" <?php selected($design['icon_size'], 'small'); ?>><?php _e('Small', 'floating-contact-button'); ?></option>
                <option value="medium" <?php selected($design['icon_size'], 'medium'); ?>><?php _e('Medium', 'floating-contact-button'); ?></option>
                <option value="large" <?php selected($design['icon_size'], 'large'); ?>><?php _e('Large', 'floating-contact-button'); ?></option>
            </select>
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_button_size"><?php _e('Button Size:', 'floating-contact-button'); ?></label>
            <select name="fcb_button_size" id="fcb_button_size">
                <option value="small" <?php selected($design['button_size'], 'small'); ?>><?php _e('Small', 'floating-contact-button'); ?></option>
                <option value="medium" <?php selected($design['button_size'], 'medium'); ?>><?php _e('Medium', 'floating-contact-button'); ?></option>
                <option value="large" <?php selected($design['button_size'], 'large'); ?>><?php _e('Large', 'floating-contact-button'); ?></option>
            </select>
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_animation_speed"><?php _e('Animation Speed:', 'floating-contact-button'); ?></label>
            <select name="fcb_animation_speed" id="fcb_animation_speed">
                <option value="slow" <?php selected(isset($design['animation_speed']) ? $design['animation_speed'] : 'normal', 'slow'); ?>><?php _e('Slow', 'floating-contact-button'); ?></option>
                <option value="normal" <?php selected(isset($design['animation_speed']) ? $design['animation_speed'] : 'normal', 'normal'); ?>><?php _e('Normal', 'floating-contact-button'); ?></option>
                <option value="fast" <?php selected(isset($design['animation_speed']) ? $design['animation_speed'] : 'normal', 'fast'); ?>><?php _e('Fast', 'floating-contact-button'); ?></option>
            </select>
        </div>
    </div>
    
    <div class="fcb-column fcb-column-30">
        <div class="fcb-preview-container">
            <h3><?php _e('Live Preview', 'floating-contact-button'); ?></h3>
            <div class="fcb-live-preview"></div>
            <p class="description"><?php _e('This is a preview of how your buttons will appear on your website.', 'floating-contact-button'); ?></p>
        </div>
    </div>
</div>
