<?php
/**
 * Plugin Name:       Floating Contact Button
 * Plugin URI:        https://example.com/floating-contact-button
 * Description:       Add customizable floating contact buttons (WhatsApp, Email, Phone, etc.) to your WordPress site.
 * Version:           1.0.0
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       floating-contact-button
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Current plugin version.
 */
define('FLOATING_CONTACT_BUTTON_VERSION', '1.0.0');

/**
 * Plugin basename.
 */
define('FLOATING_CONTACT_BUTTON_BASENAME', plugin_basename(__FILE__));

/**
 * Plugin directory path.
 */
define('FLOATING_CONTACT_BUTTON_DIR', plugin_dir_path(__FILE__));

/**
 * Plugin directory URL.
 */
define('FLOATING_CONTACT_BUTTON_URL', plugin_dir_url(__FILE__));

/**
 * The code that runs during plugin activation.
 */
function activate_floating_contact_button() {
    // Set default options if they don't exist
    if (!get_option('fcb_buttons')) {
        $default_buttons = array(
            array(
                'type' => 'whatsapp',
                'value' => '',
                'label' => __('Chat on WhatsApp', 'floating-contact-button'),
                'icon' => 'fab fa-whatsapp',
                'bg_color' => '#25D366',
                'icon_color' => '#FFFFFF',
                'order' => 1,
            ),
            array(
                'type' => 'email',
                'value' => '',
                'label' => __('Send Email', 'floating-contact-button'),
                'icon' => 'fas fa-envelope',
                'bg_color' => '#FF5722',
                'icon_color' => '#FFFFFF',
                'order' => 2,
            ),
        );
        update_option('fcb_buttons', $default_buttons);
    }

    if (!get_option('fcb_placement')) {
        $default_placement = array(
            'position' => 'bottom-right',
            'visibility' => 'all',
            'specific_pages' => array(),
            'spacing' => '20',
        );
        update_option('fcb_placement', $default_placement);
    }

    if (!get_option('fcb_design')) {
        $default_design = array(
            'button_shape' => 'round',
            'shadow' => 'on',
            'icon_size' => 'medium',
            'button_size' => 'medium',
        );
        update_option('fcb_design', $default_design);
    }
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_floating_contact_button() {
    // Nothing to do here for now
}

register_activation_hook(__FILE__, 'activate_floating_contact_button');
register_deactivation_hook(__FILE__, 'deactivate_floating_contact_button');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-fcb.php';

/**
 * Begins execution of the plugin.
 */
function run_floating_contact_button() {
    $plugin = new Floating_Contact_Button();
    $plugin->run();
}
run_floating_contact_button();
