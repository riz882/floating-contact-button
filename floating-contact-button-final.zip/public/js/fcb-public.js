(function($) {
    'use strict';

    $(document).ready(function() {
        // Main button toggle functionality
        $('.fcb-main-button').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const $container = $(this).closest('.fcb-container');
            
            // Toggle the open state
            if ($container.hasClass('fcb-open')) {
                closeButtons($container);
            } else {
                openButtons($container);
            }
        });
        
        // No close button functionality
        
        // Function to open buttons
        function openButtons($container) {
            // Add the open class to show the buttons wrapper
            $container.addClass('fcb-open');
            
            // Reset any inline styles that might be preventing display
            $container.find('.fcb-button').css({
                'opacity': '',
                'transform': ''
            });
        }
        
        // Function to close buttons
        function closeButtons($container) {
            // First animate the buttons out
            const $buttons = $container.find('.fcb-button');
            $buttons.css({
                'opacity': '0',
                'transform': 'scale(0.5) translateY(20px)'
            });
            
            // After animation finishes, remove the open class
            setTimeout(function() {
                $container.removeClass('fcb-open');
            }, 300); // Match this with your CSS transition time
        }
        
        // Add hover effects for contact buttons
        $(document).on('mouseenter', '.fcb-button', function() {
            // Show tooltip on hover
            $(this).find('.fcb-tooltip').css({
                'visibility': 'visible',
                'opacity': '1'
            });
        });
        
        $(document).on('mouseleave', '.fcb-button', function() {
            // Hide tooltip on mouse leave
            $(this).find('.fcb-tooltip').css({
                'visibility': 'hidden',
                'opacity': '0'
            });
        });
        
        // Handle click events for contact buttons
        $(document).on('click', '.fcb-button', function(e) {
            // Track clicks via analytics if available
            if (typeof gtag === 'function') {
                const buttonType = $(this).data('type');
                gtag('event', 'click', {
                    'event_category': 'Floating Contact Button',
                    'event_label': buttonType
                });
            }
        });
        
        // Close buttons when clicking outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.fcb-container').length) {
                $('.fcb-container').each(function() {
                    if ($(this).hasClass('fcb-open')) {
                        closeButtons($(this));
                    }
                });
            }
        });
    });

})(jQuery);
