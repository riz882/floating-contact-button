<?php
/**
 * Public display for floating contact buttons
 *
 * @package    Floating_Contact_Button
 * @subpackage Floating_Contact_Button/public/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Extract data
$buttons = $data['buttons'];
$placement = $data['placement'];
$design = $data['design'];

// Get the spacing
$spacing = isset($placement['spacing']) ? intval($placement['spacing']) : 20;

// Initialize public class to use its methods
$public = new Floating_Contact_Button_Public($this->plugin_name, $this->version);

// Position class with more options now
$position_class = 'fcb-position-' . esc_attr($placement['position']);

// Animation speed will be applied to container

// Position style based on new placement options
$position_style = '';
switch ($placement['position']) {
    case 'bottom-right':
        $position_style = "right: {$spacing}px; bottom: {$spacing}px;";
        break;
    case 'bottom-left':
        $position_style = "left: {$spacing}px; bottom: {$spacing}px;";
        break;
    case 'bottom-center':
        $position_style = "bottom: {$spacing}px;";
        break;
    case 'middle-right':
        $position_style = "right: {$spacing}px;";
        break;
    case 'middle-left':
        $position_style = "left: {$spacing}px;";
        break;
    case 'top-right':
        $position_style = "right: {$spacing}px; top: {$spacing}px;";
        break;
    case 'top-left':
        $position_style = "left: {$spacing}px; top: {$spacing}px;";
        break;
    case 'top-center':
        $position_style = "top: {$spacing}px;";
        break;
    default:
        $position_style = "right: {$spacing}px; bottom: {$spacing}px;";
}
?>

<?php
// Add animation speed class
$animation_speed = isset($design['animation_speed']) ? esc_attr($design['animation_speed']) : 'normal';
$animation_class = 'fcb-animation-' . $animation_speed;
?>
<div class="fcb-container <?php echo $position_class; ?> <?php echo $animation_class; ?>" style="<?php echo $position_style; ?>">
    <?php 
    // Main button that toggles the contact options
    $main_bg_color = isset($design['main_bg_color']) ? esc_attr($design['main_bg_color']) : '#4A90E2';
    $main_icon_color = isset($design['main_icon_color']) ? esc_attr($design['main_icon_color']) : '#FFFFFF';
    $main_icon = isset($design['main_icon']) ? esc_attr($design['main_icon']) : 'fas fa-comments';
    ?>
    <div class="fcb-main-button" style="background-color: <?php echo $main_bg_color; ?>;">
        <i class="<?php echo $main_icon; ?>" style="color: <?php echo $main_icon_color; ?>;"></i>
    </div>
    
    <?php // Contact buttons wrapper ?>
    <div class="fcb-buttons-wrapper">
        <?php
        if (!empty($buttons) && is_array($buttons)) {
            foreach ($buttons as $button) : 
                if (!isset($button['type']) || !isset($button['icon'])) {
                    continue; // Skip malformed buttons
                }
                
                // Get button URL (handles empty values gracefully)
                $url = $public->get_button_url($button);
                
                // Get button classes
                $button_classes = array(
                    'fcb-button',
                    'fcb-shape-' . esc_attr($design['button_shape']),
                    'fcb-size-' . esc_attr($design['button_size']),
                    'fcb-icon-size-' . esc_attr($design['icon_size']),
                );
                
                if ($design['shadow'] === 'on') {
                    $button_classes[] = 'fcb-shadow';
                }
                
                $button_class = implode(' ', $button_classes);
                
                // Background color with fallback
                $bg_color = isset($button['bg_color']) ? $button['bg_color'] : '#25D366';
                
                // Icon color with fallback
                $icon_color = isset($button['icon_color']) ? $button['icon_color'] : '#FFFFFF';
                ?>
                <a href="<?php echo esc_url($url); ?>" 
                   class="<?php echo esc_attr($button_class); ?>" 
                   target="_blank" 
                   rel="noopener noreferrer"
                   data-type="<?php echo esc_attr($button['type']); ?>"
                   style="background-color: <?php echo esc_attr($bg_color); ?>;">
                    
                    <i class="<?php echo esc_attr($button['icon']); ?>" style="color: <?php echo esc_attr($icon_color); ?>;"></i>
                    
                    <?php if (!empty($button['label'])) : ?>
                        <span class="fcb-tooltip"><?php echo esc_html($button['label']); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach;
        } ?>
    </div>
</div>
