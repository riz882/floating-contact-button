<?php
/**
 * Buttons Manager tab
 *
 * @package    Floating_Contact_Button
 * @subpackage Floating_Contact_Button/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get the admin class instance
$admin = new Floating_Contact_Button_Admin($this->plugin_name, $this->version);

// Get saved buttons
$buttons = get_option('fcb_buttons', array());

// Get button types
$button_types = $admin->get_button_types();

// Get Font Awesome icons
$fa_icons = $admin->get_fa_icons();
?>

<div class="fcb-columns">
    <div class="fcb-column fcb-column-70">
        <div class="fcb-section-title">
            <h3><?php _e('Contact Buttons', 'floating-contact-button'); ?></h3>
            <p><?php _e('Add and configure the floating contact buttons. Drag and drop to reorder.', 'floating-contact-button'); ?></p>
        </div>
        
        <!-- Buttons Container -->
        <div class="fcb-buttons-container">
            <?php if (!empty($buttons)) : ?>
                <?php foreach ($buttons as $index => $button) : ?>
                    <div class="fcb-button-item">
                        <div class="fcb-button-header">
                            <div class="fcb-button-title">
                                <span class="fcb-button-move dashicons dashicons-move"></span>
                                <?php echo esc_html($button_types[$button['type']]['label']); ?>
                            </div>
                            <div class="fcb-button-actions">
                                <span class="fcb-button-toggle dashicons dashicons-arrow-down-alt2"></span>
                                <span class="fcb-button-remove dashicons dashicons-no-alt"></span>
                            </div>
                        </div>
                        <div class="fcb-button-content">
                            <input type="hidden" class="fcb-button-order" value="<?php echo esc_attr($button['order']); ?>">
                            
                            <div class="fcb-form-row">
                                <label for="fcb-button-type-<?php echo $index; ?>"><?php _e('Button Type:', 'floating-contact-button'); ?></label>
                                <select id="fcb-button-type-<?php echo $index; ?>" class="fcb-button-type">
                                    <?php foreach ($button_types as $type => $type_data) : ?>
                                        <option value="<?php echo esc_attr($type); ?>" <?php selected($button['type'], $type); ?>>
                                            <?php echo esc_html($type_data['label']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="fcb-form-row">
                                <label for="fcb-button-value-<?php echo $index; ?>" class="fcb-value-label">
                                    <?php 
                                    switch ($button['type']) {
                                        case 'whatsapp':
                                            _e('WhatsApp Number:', 'floating-contact-button');
                                            break;
                                        case 'email':
                                            _e('Email Address:', 'floating-contact-button');
                                            break;
                                        case 'phone':
                                            _e('Phone Number:', 'floating-contact-button');
                                            break;
                                        case 'messenger':
                                            _e('Messenger Username or URL:', 'floating-contact-button');
                                            break;
                                        case 'telegram':
                                            _e('Telegram Username:', 'floating-contact-button');
                                            break;
                                        case 'custom':
                                            _e('URL:', 'floating-contact-button');
                                            break;
                                        default:
                                            _e('Value:', 'floating-contact-button');
                                    }
                                    ?>
                                </label>
                                <input type="text" id="fcb-button-value-<?php echo $index; ?>" class="fcb-button-value" 
                                    value="<?php echo esc_attr($button['value']); ?>" 
                                    placeholder="<?php 
                                        switch ($button['type']) {
                                            case 'whatsapp':
                                                echo esc_attr('e.g., 12345678901 (with country code, no + or spaces)');
                                                break;
                                            case 'email':
                                                echo esc_attr('e.g., your@email.com');
                                                break;
                                            case 'phone':
                                                echo esc_attr('e.g., +12345678901');
                                                break;
                                            case 'messenger':
                                                echo esc_attr('e.g., username or full URL');
                                                break;
                                            case 'telegram':
                                                echo esc_attr('e.g., username (without @)');
                                                break;
                                            case 'custom':
                                                echo esc_attr('e.g., https://example.com');
                                                break;
                                        }
                                    ?>"
                                >
                            </div>
                            
                            <div class="fcb-form-row">
                                <label for="fcb-button-label-<?php echo $index; ?>"><?php _e('Button Label (tooltip):', 'floating-contact-button'); ?></label>
                                <input type="text" id="fcb-button-label-<?php echo $index; ?>" class="fcb-button-label" 
                                    value="<?php echo esc_attr($button['label']); ?>" 
                                    placeholder="<?php _e('e.g., Chat on WhatsApp', 'floating-contact-button'); ?>">
                            </div>
                            
                            <div class="fcb-form-row">
                                <label for="fcb-button-icon-<?php echo $index; ?>"><?php _e('Button Icon:', 'floating-contact-button'); ?></label>
                                <select id="fcb-button-icon-<?php echo $index; ?>" class="fcb-button-icon">
                                    <?php foreach ($fa_icons as $icon => $icon_name) : ?>
                                        <option value="<?php echo esc_attr($icon); ?>" <?php selected($button['icon'], $icon); ?>>
                                            <i class="<?php echo esc_attr($icon); ?>"></i> <?php echo esc_html($icon_name); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="fcb-form-row">
                                <label for="fcb-button-bg-color-<?php echo $index; ?>"><?php _e('Background Color:', 'floating-contact-button'); ?></label>
                                <input type="text" id="fcb-button-bg-color-<?php echo $index; ?>" class="fcb-button-bg-color fcb-color-picker" 
                                    value="<?php echo esc_attr($button['bg_color']); ?>" data-default-color="<?php echo esc_attr($button_types[$button['type']]['default_color']); ?>">
                            </div>
                            
                            <div class="fcb-form-row">
                                <label for="fcb-button-icon-color-<?php echo $index; ?>"><?php _e('Icon Color:', 'floating-contact-button'); ?></label>
                                <input type="text" id="fcb-button-icon-color-<?php echo $index; ?>" class="fcb-button-icon-color fcb-color-picker" 
                                    value="<?php echo esc_attr($button['icon_color']); ?>" data-default-color="#FFFFFF">
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Add Button -->
        <div class="fcb-add-button-container">
            <button type="button" id="fcb-add-button" class="button">
                <span class="dashicons dashicons-plus-alt"></span> <?php _e('Add New Button', 'floating-contact-button'); ?>
            </button>
        </div>
        
        <!-- Button Template (Hidden) -->
        <div class="fcb-button-template" style="display: none;">
            <div class="fcb-button-header">
                <div class="fcb-button-title">
                    <span class="fcb-button-move dashicons dashicons-move"></span>
                    <?php _e('New Button', 'floating-contact-button'); ?>
                </div>
                <div class="fcb-button-actions">
                    <span class="fcb-button-toggle dashicons dashicons-arrow-down-alt2"></span>
                    <span class="fcb-button-remove dashicons dashicons-no-alt"></span>
                </div>
            </div>
            <div class="fcb-button-content">
                <input type="hidden" class="fcb-button-order" value="1" disabled>
                
                <div class="fcb-form-row">
                    <label><?php _e('Button Type:', 'floating-contact-button'); ?></label>
                    <select class="fcb-button-type" disabled>
                        <?php foreach ($button_types as $type => $type_data) : ?>
                            <option value="<?php echo esc_attr($type); ?>">
                                <?php echo esc_html($type_data['label']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="fcb-form-row">
                    <label class="fcb-value-label"><?php _e('Value:', 'floating-contact-button'); ?></label>
                    <input type="text" class="fcb-button-value" value="" placeholder="" disabled>
                </div>
                
                <div class="fcb-form-row">
                    <label><?php _e('Button Label (tooltip):', 'floating-contact-button'); ?></label>
                    <input type="text" class="fcb-button-label" value="" placeholder="<?php _e('e.g., Chat on WhatsApp', 'floating-contact-button'); ?>" disabled>
                </div>
                
                <div class="fcb-form-row">
                    <label><?php _e('Button Icon:', 'floating-contact-button'); ?></label>
                    <select class="fcb-button-icon" disabled>
                        <?php foreach ($fa_icons as $icon => $icon_name) : ?>
                            <option value="<?php echo esc_attr($icon); ?>">
                                <?php echo esc_html($icon_name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="fcb-form-row">
                    <label><?php _e('Background Color:', 'floating-contact-button'); ?></label>
                    <input type="text" class="fcb-button-bg-color fcb-color-picker" value="#25D366" disabled>
                </div>
                
                <div class="fcb-form-row">
                    <label><?php _e('Icon Color:', 'floating-contact-button'); ?></label>
                    <input type="text" class="fcb-button-icon-color fcb-color-picker" value="#FFFFFF" disabled>
                </div>
            </div>
        </div>
    </div>
    
    <div class="fcb-column fcb-column-30">
        <div class="fcb-preview-container">
            <h3><?php _e('Live Preview', 'floating-contact-button'); ?></h3>
            <div class="fcb-live-preview"></div>
            <p class="description"><?php _e('This is a preview of how your buttons will appear on your website.', 'floating-contact-button'); ?></p>
        </div>
    </div>
</div>
