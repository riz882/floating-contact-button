<?php
/**
 * Main admin display for the plugin
 *
 * @package    Floating_Contact_Button
 * @subpackage Floating_Contact_Button/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get the active tab
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'buttons_manager';
?>

<div class="wrap fcb-wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <?php settings_errors('fcb_messages'); ?>
    
    <h2 class="nav-tab-wrapper fcb-nav-tab-wrapper">
        <a href="#buttons_manager" class="nav-tab <?php echo $active_tab == 'buttons_manager' ? 'nav-tab-active' : ''; ?>">
            <span class="dashicons dashicons-button"></span> <?php _e('Buttons Manager', 'floating-contact-button'); ?>
        </a>
        <a href="#placement" class="nav-tab <?php echo $active_tab == 'placement' ? 'nav-tab-active' : ''; ?>">
            <span class="dashicons dashicons-location"></span> <?php _e('Placement', 'floating-contact-button'); ?>
        </a>
        <a href="#design" class="nav-tab <?php echo $active_tab == 'design' ? 'nav-tab-active' : ''; ?>">
            <span class="dashicons dashicons-admin-appearance"></span> <?php _e('Design & Style', 'floating-contact-button'); ?>
        </a>
    </h2>
    
    <form method="post" action="" id="fcb-settings-form">
        <?php wp_nonce_field('fcb_settings_nonce', 'fcb_nonce'); ?>
        <input type="hidden" name="fcb_form_submitted" value="1">
        <input type="hidden" name="fcb_form_tab" id="fcb_form_tab" value="<?php echo esc_attr($active_tab); ?>">
        
        <!-- Hidden field to store JSON data of buttons -->
        <input type="hidden" name="fcb_buttons_data" id="fcb_buttons_data" value="">
        
        <!-- Buttons Manager Tab -->
        <div id="buttons_manager" class="fcb-tab-content">
            <?php include 'fcb-admin-buttons-manager.php'; ?>
        </div>
        
        <!-- Placement Tab -->
        <div id="placement" class="fcb-tab-content">
            <?php include 'fcb-admin-placement.php'; ?>
        </div>
        
        <!-- Design & Style Tab -->
        <div id="design" class="fcb-tab-content">
            <?php include 'fcb-admin-design.php'; ?>
        </div>
        
        <?php submit_button(__('Save Settings', 'floating-contact-button'), 'primary', 'submit', true); ?>
    </form>
</div>
