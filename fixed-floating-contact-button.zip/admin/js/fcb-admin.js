(function($) {
    'use strict';

    // Initialize colorpickers
    function initColorPickers() {
        $('.fcb-color-picker').wpColorPicker({
            change: function(event, ui) {
                // Update preview when color changes
                updatePreview();
            }
        });
    }

    // Initialize sortable buttons
    function initSortable() {
        $('.fcb-buttons-container').sortable({
            handle: '.fcb-button-header', // Changed from .fcb-button-move to .fcb-button-header
            cursor: 'move',
            tolerance: 'pointer',
            update: function(event, ui) {
                // Update order values after sorting
                updateButtonOrder();
                // Update the preview
                updatePreview();
            }
        });
    }

    // Initialize button type select change handlers
    function initButtonTypeHandlers() {
        $(document).on('change', '.fcb-button-type', function() {
            const $button = $(this).closest('.fcb-button-item');
            const type = $(this).val();
            
            // Update the icon and colors based on button type
            const $iconSelect = $button.find('.fcb-button-icon');
            const $bgColor = $button.find('.fcb-button-bg-color');
            const $iconColor = $button.find('.fcb-button-icon-color');
            const $valueField = $button.find('.fcb-button-value');
            const $valueLabel = $button.find('.fcb-value-label');
            
            // Update placeholders and field types based on button type
            switch(type) {
                case 'whatsapp':
                    $iconSelect.val('fab fa-whatsapp').trigger('change');
                    $bgColor.wpColorPicker('color', '#25D366');
                    $iconColor.wpColorPicker('color', '#FFFFFF');
                    $valueLabel.text('WhatsApp Number:');
                    $valueField.attr('placeholder', 'e.g., 12345678901 (with country code, no + or spaces)');
                    break;
                case 'email':
                    $iconSelect.val('fas fa-envelope').trigger('change');
                    $bgColor.wpColorPicker('color', '#FF5722');
                    $iconColor.wpColorPicker('color', '#FFFFFF');
                    $valueLabel.text('Email Address:');
                    $valueField.attr('placeholder', 'e.g., your@email.com');
                    break;
                case 'phone':
                    $iconSelect.val('fas fa-phone-alt').trigger('change');
                    $bgColor.wpColorPicker('color', '#4CAF50');
                    $iconColor.wpColorPicker('color', '#FFFFFF');
                    $valueLabel.text('Phone Number:');
                    $valueField.attr('placeholder', 'e.g., +12345678901');
                    break;
                case 'messenger':
                    $iconSelect.val('fab fa-facebook-messenger').trigger('change');
                    $bgColor.wpColorPicker('color', '#0084FF');
                    $iconColor.wpColorPicker('color', '#FFFFFF');
                    $valueLabel.text('Messenger Username or URL:');
                    $valueField.attr('placeholder', 'e.g., username or full URL');
                    break;
                case 'telegram':
                    $iconSelect.val('fab fa-telegram-plane').trigger('change');
                    $bgColor.wpColorPicker('color', '#0088cc');
                    $iconColor.wpColorPicker('color', '#FFFFFF');
                    $valueLabel.text('Telegram Username:');
                    $valueField.attr('placeholder', 'e.g., username (without @)');
                    break;
                case 'custom':
                    $iconSelect.val('fas fa-link').trigger('change');
                    $bgColor.wpColorPicker('color', '#2196F3');
                    $iconColor.wpColorPicker('color', '#FFFFFF');
                    $valueLabel.text('URL:');
                    $valueField.attr('placeholder', 'e.g., https://example.com');
                    break;
            }
        });
    }

    // Update button order after sorting
    function updateButtonOrder() {
        $('.fcb-button-item').each(function(index) {
            $(this).find('.fcb-button-order').val(index + 1);
        });
    }

    // Add new button
    function addNewButton() {
        // Clone the button template
        const $template = $('.fcb-button-template').clone();
        $template.removeClass('fcb-button-template').addClass('fcb-button-item');
        $template.find('input, select, textarea').prop('disabled', false);
        
        // Set default values
        $template.find('.fcb-button-order').val($('.fcb-button-item').length + 1);
        $template.find('.fcb-button-label').val('New Button');
        
        // Append to container
        $('.fcb-buttons-container').append($template);
        
        // Initialize color pickers for the new button
        $template.find('.fcb-color-picker').wpColorPicker({
            change: function(event, ui) {
                updatePreview();
            }
        });
        
        // Make visible
        $template.show();
        
        // Trigger change to set default icon and colors
        $template.find('.fcb-button-type').trigger('change');
        
        // Update preview
        updatePreview();
    }

    // Remove button
    function removeButton(buttonElement) {
        $(buttonElement).closest('.fcb-button-item').remove();
        updateButtonOrder();
        updatePreview();
    }

    // Collect button data for saving or preview
    function collectButtonData() {
        const buttons = [];
        
        $('.fcb-button-item').each(function() {
            const $button = $(this);
            
            buttons.push({
                type: $button.find('.fcb-button-type').val(),
                value: $button.find('.fcb-button-value').val(),
                label: $button.find('.fcb-button-label').val(),
                icon: $button.find('.fcb-button-icon').val(),
                bg_color: $button.find('.fcb-button-bg-color').val(),
                icon_color: $button.find('.fcb-button-icon-color').val(),
                order: parseInt($button.find('.fcb-button-order').val())
            });
        });
        
        // Sort by order
        buttons.sort((a, b) => a.order - b.order);
        
        return buttons;
    }

    // Update the preview
    function updatePreview() {
        const $preview = $('.fcb-live-preview');
        if ($preview.length === 0) return;
        
        const buttons = collectButtonData();
        const position = $('#fcb_position').val() || 'bottom-right';
        const buttonShape = $('#fcb_button_shape').val() || 'round';
        const shadow = $('#fcb_shadow').val() || 'on';
        const iconSize = $('#fcb_icon_size').val() || 'medium';
        const buttonSize = $('#fcb_button_size').val() || 'medium';
        
        // Clear current preview
        $preview.empty();
        
        // Create container
        const $container = $('<div>').addClass('fcb-preview-buttons-container')
            .addClass('fcb-position-' + position);
        
        // Add each button to preview
        buttons.forEach(function(button) {
            const $btn = $('<div>').addClass('fcb-preview-button')
                .addClass('fcb-shape-' + buttonShape)
                .addClass('fcb-size-' + buttonSize)
                .addClass('fcb-icon-size-' + iconSize);
            
            if (shadow === 'on') {
                $btn.addClass('fcb-shadow');
            }
            
            $btn.css({
                'background-color': button.bg_color
            });
            
            // Add icon
            const $icon = $('<i>').addClass(button.icon)
                .css('color', button.icon_color);
            
            $btn.append($icon);
            
            // Add tooltip if label exists
            if (button.label) {
                const $tooltip = $('<span>').addClass('fcb-preview-tooltip')
                    .text(button.label);
                $btn.append($tooltip);
            }
            
            $container.append($btn);
        });
        
        $preview.append($container);
    }

    // Initialize the page when DOM is ready
    $(function() {
        // Initialize colorpickers
        initColorPickers();
        
        // Initialize sortable
        initSortable();
        
        // Initialize button type handlers
        initButtonTypeHandlers();
        
        // Add new button
        $(document).on('click', '#fcb-add-button', function(e) {
            e.preventDefault();
            addNewButton();
        });
        
        // Remove button
        $(document).on('click', '.fcb-button-remove', function(e) {
            e.preventDefault();
            removeButton(this);
        });
        
        // Toggle button content visibility
        $(document).on('click', '.fcb-button-toggle', function(e) {
            e.preventDefault();
            const $button = $(this).closest('.fcb-button-item');
            const $content = $button.find('.fcb-button-content');
            
            // Toggle content visibility
            $content.slideToggle(200);
            
            // Toggle icon between down and up arrow
            $(this).toggleClass('dashicons-arrow-down-alt2 dashicons-arrow-up-alt2');
        });
        
        // Handle tab navigation
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            
            // Update active tab class
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            // Show/hide tab content
            const tabId = $(this).attr('href').substring(1);
            $('.fcb-tab-content').hide();
            $('#' + tabId).show();
            
            // Update hidden tab input
            $('#fcb_form_tab').val(tabId);
        });
        
        // Prepare form data before submit
        $('#fcb-settings-form').on('submit', function() {
            // Collect button data and set to hidden input
            const buttonData = collectButtonData();
            $('#fcb_buttons_data').val(JSON.stringify(buttonData));
        });
        
        // Initialize preview
        updatePreview();
        
        // Update preview when form elements change
        $(document).on('change', '.fcb-button-type, .fcb-button-value, .fcb-button-label, .fcb-button-icon, #fcb_position, #fcb_button_shape, #fcb_shadow, #fcb_icon_size, #fcb_button_size', function() {
            updatePreview();
        });
        
        // Show the active tab
        const activeTab = $('.nav-tab-active').attr('href').substring(1);
        $('#' + activeTab).show();
    });

})(jQuery);
