=== Floating Contact Button ===
Contributors: yourname
Donate link: https://example.com/
Tags: contact, whatsapp, floating button, social media, email, telegram, messenger
Requires at least: 5.0
Tested up to: 6.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add modern, customizable floating contact buttons to your WordPress site with this easy-to-use plugin.

== Description ==

Floating Contact Button is a WordPress plugin that adds modern, eye-catching floating contact buttons to your website. Enable your visitors to contact you instantly through WhatsApp, Email, Phone, Facebook Messenger, Telegram, or any custom URL.

= Key Features =

* **Multiple Contact Types**
  * WhatsApp
  * Email
  * Phone
  * Facebook Messenger
  * Telegram
  * Custom URL (e.g., booking page)

* **Highly Customizable**
  * Choose button position (bottom-right or bottom-left)
  * Select button shape (round, rounded square, pill)
  * Customize colors for each button
  * Select button size and icon size
  * Enable/disable shadow effect

* **Flexible Placement**
  * Show on all pages
  * Show only on homepage
  * Show on specific pages or posts

* **Responsive Design**
  * Works perfectly on both desktop and mobile devices

* **Easy Management**
  * Add, edit, delete, and reorder buttons with ease
  * Live preview while editing

= Perfect For =

* Small businesses and freelancers
* E-commerce websites
* Service providers
* Any website that wants to improve customer communication

= No Coding Required =

All settings can be managed through the user-friendly admin interface — no technical skills needed!

== Installation ==

1. Upload the `floating-contact-button` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure the floating buttons through the 'Floating Contact' menu in your admin dashboard

== Frequently Asked Questions ==

= How do I add a WhatsApp button? =

1. Go to Floating Contact > Buttons Manager
2. Click "Add New Button"
3. Select "WhatsApp" as the button type
4. Enter your WhatsApp number (with country code, no + or spaces)
5. Customize colors and label as needed
6. Save settings

= Can I show different buttons on different pages? =

Yes! Go to the Placement tab and select "Specific pages" in the Visibility setting. Then you can choose which pages or posts to show the buttons on.

= Does it work with any WordPress theme? =

Yes, the plugin is designed to be compatible with all modern WordPress themes.

= How can I change the position of the buttons? =

Go to the Placement tab and choose either "Bottom Right" or "Bottom Left" from the Position selector.

= Can I reorder the buttons? =

Yes, in the Buttons Manager tab, you can drag and drop the buttons to change their order.

== Screenshots ==

1. Front-end display of floating contact buttons
2. Admin interface - Buttons Manager
3. Admin interface - Placement Settings
4. Admin interface - Design & Style

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
Initial release
