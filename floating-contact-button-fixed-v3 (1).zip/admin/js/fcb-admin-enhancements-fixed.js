/**
 * Admin panel enhancements for the Floating Contact Button plugin.
 * Adds country selector for WhatsApp and range slider for spacing.
 */

(function($) {
    'use strict';

    /**
     * Initialize the WhatsApp country selector with IntlTelInput
     */
    function initWhatsAppCountrySelector() {
        // Apply to all existing WhatsApp input fields
        $('.fcb-button-type').each(function() {
            if ($(this).val() === 'whatsapp') {
                const valueInput = $(this).closest('.fcb-button-content').find('.fcb-button-value');
                if (!valueInput.hasClass('iti-enabled')) {
                    applyIntlTelInput(valueInput);
                }
            }
        });

        // Add listener for button type changes to apply/remove phone input
        $(document).on('change', '.fcb-button-type', function() {
            const valueInput = $(this).closest('.fcb-button-content').find('.fcb-button-value');
            
            // If changing to WhatsApp
            if ($(this).val() === 'whatsapp') {
                if (!valueInput.hasClass('iti-enabled')) {
                    applyIntlTelInput(valueInput);
                }
            } 
            // If changing from WhatsApp to something else
            else if (valueInput.hasClass('iti-enabled')) {
                // Get the actual value
                const number = valueInput.val();
                
                // Destroy the intlTelInput instance
                const iti = valueInput.data('iti');
                if (iti) {
                    iti.destroy();
                }
                
                // Remove classes and reset the input
                valueInput.removeClass('iti-enabled fcb-valid-input fcb-invalid-input');
                valueInput.parent().find('.fcb-validation-error').remove();
                valueInput.parent().find('.country-selector-container, .phone-number-label, .country-selector-label').remove();
                valueInput.val(number);
            }
        });

        // Also handle new buttons being added
        $(document).on('fcb:buttonAdded', function(e, buttonElement) {
            const buttonType = $(buttonElement).find('.fcb-button-type');
            if (buttonType.val() === 'whatsapp') {
                const valueInput = $(buttonElement).find('.fcb-button-value');
                if (!valueInput.hasClass('iti-enabled')) {
                    applyIntlTelInput(valueInput);
                }
            }
        });
    }

    /**
     * Apply IntlTelInput to a specific input element
     */
    function applyIntlTelInput(inputElement) {
        // If IntlTelInput is not loaded yet, try to load it
        if (typeof window.intlTelInput !== 'function') {
            if (!$('script[src*="intl-tel-input"]').length) {
                // Load CSS
                $('head').append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css">');
                
                // Load JavaScript and initialize when loaded
                $.getScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js', function() {
                    $.getScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js', function() {
                        // Now initialize the input
                        initializeIntlTelInputInstance(inputElement);
                    });
                });
                return;
            }
        }
        
        // Initialize directly if already loaded
        initializeIntlTelInputInstance(inputElement);
    }
    
    /**
     * Initialize an instance of IntlTelInput
     */
    function initializeIntlTelInputInstance(inputElement) {
        // Add country selector label first
        inputElement.before('<label class="country-selector-label">Select Country:</label>');
        
        // Create container for country selector
        inputElement.before('<div class="country-selector-container"></div>');
        
        // Initialize the tel input
        const iti = window.intlTelInput(inputElement[0], {
            utilsScript: 'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js',
            separateDialCode: true,
            initialCountry: 'auto',
            geoIpLookup: function(callback) {
                // Use a free geolocation API to get the user's country
                $.get('https://ipinfo.io', function() {}, 'jsonp').always(function(resp) {
                    const countryCode = (resp && resp.country) ? resp.country : 'us';
                    callback(countryCode);
                });
            },
            dropdownContainer: document.body,
            autoPlaceholder: 'aggressive'
        });
        
        // Store reference to the iti instance
        inputElement.data('iti', iti);
        inputElement.addClass('iti-enabled');
        
        // Add a slight delay to allow the DOM to update
        setTimeout(function() {
            // Move the flag container into our custom container
            const $flagContainer = inputElement.closest('.iti').find('.iti__flag-container');
            inputElement.closest('.iti').find('.country-selector-container').append($flagContainer);
            
            // Add phone number label
            inputElement.before('<label class="phone-number-label">Phone Number (without country code):</label>');
        }, 100);
        
        // Add validation for the phone number
        inputElement.on('blur', function() {
            // Check number validity when field loses focus
            if (inputElement.val()) {
                if (iti.isValidNumber()) {
                    inputElement.removeClass('fcb-invalid-input').addClass('fcb-valid-input');
                    inputElement.parent().find('.fcb-validation-error').remove();
                } else {
                    inputElement.removeClass('fcb-valid-input').addClass('fcb-invalid-input');
                    if (!inputElement.parent().find('.fcb-validation-error').length) {
                        inputElement.parent().append('<div class="fcb-validation-error">Invalid phone number. Please check the number format.</div>');
                    }
                }
            } else {
                // Empty field is not invalid but not valid either
                inputElement.removeClass('fcb-valid-input fcb-invalid-input');
                inputElement.parent().find('.fcb-validation-error').remove();
            }
        });
    }

    /**
     * Initialize the spacing range slider
     */
    function initSpacingRangeSlider() {
        const $spacingInput = $('#fcb_spacing');
        
        if ($spacingInput.length && !$spacingInput.hasClass('slider-initialized')) {
            // Create a slider container if it doesn't exist
            if (!$('.fcb-spacing-control-wrapper').length) {
                $spacingInput.wrap('<div class="fcb-spacing-control-wrapper"></div>');
                const $wrapper = $spacingInput.parent();
                
                // Add the slider and value display
                $wrapper.append('<div class="fcb-slider-container"><div class="fcb-spacing-slider"></div><div class="fcb-slider-value">' + $spacingInput.val() + 'px</div></div>');
            }
            
            // Get references to new elements
            const $sliderElement = $('.fcb-spacing-slider');
            const $valueDisplay = $('.fcb-slider-value');
            const currentValue = parseInt($spacingInput.val(), 10) || 20;
            
            // Initialize jQuery UI slider
            $sliderElement.slider({
                min: 0,
                max: 100,
                value: currentValue,
                slide: function(event, ui) {
                    // Update both the original input and the value display
                    $spacingInput.val(ui.value);
                    $valueDisplay.text(ui.value + 'px');
                }
            });
            
            // Connect the number input to the slider
            $spacingInput.on('input', function() {
                const val = parseInt($(this).val(), 10);
                if (!isNaN(val)) {
                    $sliderElement.slider('value', val);
                    $valueDisplay.text(val + 'px');
                }
            });
            
            // Make sure the styling is applied
            $spacingInput.addClass('fcb-spacing-number-input slider-initialized');
        }
    }

    /**
     * Initialize enhancements when document is ready
     */
    $(document).ready(function() {
        // Only run on the plugin's admin page
        if ($('body.floating-contact-button_page_floating-contact-button').length || 
            $('body.toplevel_page_floating-contact-button').length) {
            
            // Load the IntlTelInput library dynamically if needed
            if (!$('script[src*="intl-tel-input"]').length) {
                $('head').append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css">');
                $.getScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js', function() {
                    $.getScript('https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js', function() {
                        initWhatsAppCountrySelector();
                    });
                });
            } else {
                initWhatsAppCountrySelector();
            }
            
            // Initialize the spacing range slider
            initSpacingRangeSlider();
        }
    });
    
})(jQuery);