/**
 * Custom WhatsApp country and phone number selector
 * Features:
 * - Country selection with search functionality
 * - Automatic phone number validation with country-specific rules
 * - Clean, separate UI for country and phone input
 */

(function($) {
    'use strict';

    // Store country data
    const countries = [
        { code: 'AF', name: 'Afghanistan', dialCode: '+93', maxLength: 9 },
        { code: 'AL', name: 'Albania', dialCode: '+355', maxLength: 9 },
        { code: 'DZ', name: 'Algeria', dialCode: '+213', maxLength: 9 },
        { code: 'AS', name: 'American Samoa', dialCode: '+1684', maxLength: 7 },
        { code: 'AD', name: 'Andorra', dialCode: '+376', maxLength: 6 },
        { code: 'AO', name: 'Angola', dialCode: '+244', maxLength: 9 },
        { code: 'AI', name: 'Anguilla', dialCode: '+1264', maxLength: 7 },
        { code: 'AG', name: 'Antigua and Barbuda', dialCode: '+1268', maxLength: 7 },
        { code: 'AR', name: 'Argentina', dialCode: '+54', maxLength: 10 },
        { code: 'AM', name: 'Armenia', dialCode: '+374', maxLength: 8 },
        { code: 'AW', name: 'Aruba', dialCode: '+297', maxLength: 7 },
        { code: 'AU', name: 'Australia', dialCode: '+61', maxLength: 9 },
        { code: 'AT', name: 'Austria', dialCode: '+43', maxLength: 11 },
        { code: 'AZ', name: 'Azerbaijan', dialCode: '+994', maxLength: 9 },
        { code: 'BS', name: 'Bahamas', dialCode: '+1242', maxLength: 7 },
        { code: 'BH', name: 'Bahrain', dialCode: '+973', maxLength: 8 },
        { code: 'BD', name: 'Bangladesh', dialCode: '+880', maxLength: 10 },
        { code: 'BB', name: 'Barbados', dialCode: '+1246', maxLength: 7 },
        { code: 'BY', name: 'Belarus', dialCode: '+375', maxLength: 9 },
        { code: 'BE', name: 'Belgium', dialCode: '+32', maxLength: 9 },
        { code: 'BZ', name: 'Belize', dialCode: '+501', maxLength: 7 },
        { code: 'BJ', name: 'Benin', dialCode: '+229', maxLength: 8 },
        { code: 'BM', name: 'Bermuda', dialCode: '+1441', maxLength: 7 },
        { code: 'BT', name: 'Bhutan', dialCode: '+975', maxLength: 8 },
        { code: 'BO', name: 'Bolivia', dialCode: '+591', maxLength: 8 },
        { code: 'BA', name: 'Bosnia and Herzegovina', dialCode: '+387', maxLength: 8 },
        { code: 'BW', name: 'Botswana', dialCode: '+267', maxLength: 8 },
        { code: 'BR', name: 'Brazil', dialCode: '+55', maxLength: 11 },
        { code: 'IO', name: 'British Indian Ocean Territory', dialCode: '+246', maxLength: 7 },
        { code: 'VG', name: 'British Virgin Islands', dialCode: '+1284', maxLength: 7 },
        { code: 'BN', name: 'Brunei', dialCode: '+673', maxLength: 7 },
        { code: 'BG', name: 'Bulgaria', dialCode: '+359', maxLength: 9 },
        { code: 'BF', name: 'Burkina Faso', dialCode: '+226', maxLength: 8 },
        { code: 'BI', name: 'Burundi', dialCode: '+257', maxLength: 8 },
        { code: 'KH', name: 'Cambodia', dialCode: '+855', maxLength: 9 },
        { code: 'CM', name: 'Cameroon', dialCode: '+237', maxLength: 9 },
        { code: 'CA', name: 'Canada', dialCode: '+1', maxLength: 10 },
        { code: 'CV', name: 'Cape Verde', dialCode: '+238', maxLength: 7 },
        { code: 'KY', name: 'Cayman Islands', dialCode: '+1345', maxLength: 7 },
        { code: 'CF', name: 'Central African Republic', dialCode: '+236', maxLength: 8 },
        { code: 'TD', name: 'Chad', dialCode: '+235', maxLength: 8 },
        { code: 'CL', name: 'Chile', dialCode: '+56', maxLength: 9 },
        { code: 'CN', name: 'China', dialCode: '+86', maxLength: 11 },
        { code: 'CO', name: 'Colombia', dialCode: '+57', maxLength: 10 },
        { code: 'KM', name: 'Comoros', dialCode: '+269', maxLength: 7 },
        { code: 'CK', name: 'Cook Islands', dialCode: '+682', maxLength: 5 },
        { code: 'CR', name: 'Costa Rica', dialCode: '+506', maxLength: 8 },
        { code: 'HR', name: 'Croatia', dialCode: '+385', maxLength: 9 },
        { code: 'CU', name: 'Cuba', dialCode: '+53', maxLength: 8 },
        { code: 'CY', name: 'Cyprus', dialCode: '+357', maxLength: 8 },
        { code: 'CZ', name: 'Czech Republic', dialCode: '+420', maxLength: 9 },
        { code: 'CD', name: 'Democratic Republic of the Congo', dialCode: '+243', maxLength: 9 },
        { code: 'DK', name: 'Denmark', dialCode: '+45', maxLength: 8 },
        { code: 'DJ', name: 'Djibouti', dialCode: '+253', maxLength: 8 },
        { code: 'DM', name: 'Dominica', dialCode: '+1767', maxLength: 7 },
        { code: 'DO', name: 'Dominican Republic', dialCode: '+1809', maxLength: 10 },
        { code: 'EC', name: 'Ecuador', dialCode: '+593', maxLength: 9 },
        { code: 'EG', name: 'Egypt', dialCode: '+20', maxLength: 10 },
        { code: 'SV', name: 'El Salvador', dialCode: '+503', maxLength: 8 },
        { code: 'GQ', name: 'Equatorial Guinea', dialCode: '+240', maxLength: 9 },
        { code: 'ER', name: 'Eritrea', dialCode: '+291', maxLength: 7 },
        { code: 'EE', name: 'Estonia', dialCode: '+372', maxLength: 8 },
        { code: 'ET', name: 'Ethiopia', dialCode: '+251', maxLength: 9 },
        { code: 'FK', name: 'Falkland Islands', dialCode: '+500', maxLength: 5 },
        { code: 'FO', name: 'Faroe Islands', dialCode: '+298', maxLength: 6 },
        { code: 'FJ', name: 'Fiji', dialCode: '+679', maxLength: 7 },
        { code: 'FI', name: 'Finland', dialCode: '+358', maxLength: 10 },
        { code: 'FR', name: 'France', dialCode: '+33', maxLength: 9 },
        { code: 'GF', name: 'French Guiana', dialCode: '+594', maxLength: 9 },
        { code: 'PF', name: 'French Polynesia', dialCode: '+689', maxLength: 6 },
        { code: 'GA', name: 'Gabon', dialCode: '+241', maxLength: 7 },
        { code: 'GM', name: 'Gambia', dialCode: '+220', maxLength: 7 },
        { code: 'GE', name: 'Georgia', dialCode: '+995', maxLength: 9 },
        { code: 'DE', name: 'Germany', dialCode: '+49', maxLength: 11 },
        { code: 'GH', name: 'Ghana', dialCode: '+233', maxLength: 9 },
        { code: 'GI', name: 'Gibraltar', dialCode: '+350', maxLength: 8 },
        { code: 'GR', name: 'Greece', dialCode: '+30', maxLength: 10 },
        { code: 'GL', name: 'Greenland', dialCode: '+299', maxLength: 6 },
        { code: 'GD', name: 'Grenada', dialCode: '+1473', maxLength: 7 },
        { code: 'GP', name: 'Guadeloupe', dialCode: '+590', maxLength: 9 },
        { code: 'GU', name: 'Guam', dialCode: '+1671', maxLength: 7 },
        { code: 'GT', name: 'Guatemala', dialCode: '+502', maxLength: 8 },
        { code: 'GN', name: 'Guinea', dialCode: '+224', maxLength: 9 },
        { code: 'GW', name: 'Guinea-Bissau', dialCode: '+245', maxLength: 7 },
        { code: 'GY', name: 'Guyana', dialCode: '+592', maxLength: 7 },
        { code: 'HT', name: 'Haiti', dialCode: '+509', maxLength: 8 },
        { code: 'HN', name: 'Honduras', dialCode: '+504', maxLength: 8 },
        { code: 'HK', name: 'Hong Kong', dialCode: '+852', maxLength: 8 },
        { code: 'HU', name: 'Hungary', dialCode: '+36', maxLength: 9 },
        { code: 'IS', name: 'Iceland', dialCode: '+354', maxLength: 7 },
        { code: 'IN', name: 'India', dialCode: '+91', maxLength: 10 },
        { code: 'ID', name: 'Indonesia', dialCode: '+62', maxLength: 12 },
        { code: 'IR', name: 'Iran', dialCode: '+98', maxLength: 10 },
        { code: 'IQ', name: 'Iraq', dialCode: '+964', maxLength: 10 },
        { code: 'IE', name: 'Ireland', dialCode: '+353', maxLength: 9 },
        { code: 'IL', name: 'Israel', dialCode: '+972', maxLength: 9 },
        { code: 'IT', name: 'Italy', dialCode: '+39', maxLength: 10 },
        { code: 'CI', name: 'Ivory Coast', dialCode: '+225', maxLength: 8 },
        { code: 'JM', name: 'Jamaica', dialCode: '+1876', maxLength: 7 },
        { code: 'JP', name: 'Japan', dialCode: '+81', maxLength: 10 },
        { code: 'JO', name: 'Jordan', dialCode: '+962', maxLength: 9 },
        { code: 'KZ', name: 'Kazakhstan', dialCode: '+7', maxLength: 10 },
        { code: 'KE', name: 'Kenya', dialCode: '+254', maxLength: 9 },
        { code: 'KI', name: 'Kiribati', dialCode: '+686', maxLength: 5 },
        { code: 'XK', name: 'Kosovo', dialCode: '+383', maxLength: 8 },
        { code: 'KW', name: 'Kuwait', dialCode: '+965', maxLength: 8 },
        { code: 'KG', name: 'Kyrgyzstan', dialCode: '+996', maxLength: 9 },
        { code: 'LA', name: 'Laos', dialCode: '+856', maxLength: 10 },
        { code: 'LV', name: 'Latvia', dialCode: '+371', maxLength: 8 },
        { code: 'LB', name: 'Lebanon', dialCode: '+961', maxLength: 8 },
        { code: 'LS', name: 'Lesotho', dialCode: '+266', maxLength: 8 },
        { code: 'LR', name: 'Liberia', dialCode: '+231', maxLength: 8 },
        { code: 'LY', name: 'Libya', dialCode: '+218', maxLength: 10 },
        { code: 'LI', name: 'Liechtenstein', dialCode: '+423', maxLength: 7 },
        { code: 'LT', name: 'Lithuania', dialCode: '+370', maxLength: 8 },
        { code: 'LU', name: 'Luxembourg', dialCode: '+352', maxLength: 9 },
        { code: 'MO', name: 'Macau', dialCode: '+853', maxLength: 8 },
        { code: 'MK', name: 'Macedonia', dialCode: '+389', maxLength: 8 },
        { code: 'MG', name: 'Madagascar', dialCode: '+261', maxLength: 9 },
        { code: 'MW', name: 'Malawi', dialCode: '+265', maxLength: 9 },
        { code: 'MY', name: 'Malaysia', dialCode: '+60', maxLength: 10 },
        { code: 'MV', name: 'Maldives', dialCode: '+960', maxLength: 7 },
        { code: 'ML', name: 'Mali', dialCode: '+223', maxLength: 8 },
        { code: 'MT', name: 'Malta', dialCode: '+356', maxLength: 8 },
        { code: 'MH', name: 'Marshall Islands', dialCode: '+692', maxLength: 7 },
        { code: 'MQ', name: 'Martinique', dialCode: '+596', maxLength: 9 },
        { code: 'MR', name: 'Mauritania', dialCode: '+222', maxLength: 8 },
        { code: 'MU', name: 'Mauritius', dialCode: '+230', maxLength: 8 },
        { code: 'YT', name: 'Mayotte', dialCode: '+262', maxLength: 9 },
        { code: 'MX', name: 'Mexico', dialCode: '+52', maxLength: 10 },
        { code: 'FM', name: 'Micronesia', dialCode: '+691', maxLength: 7 },
        { code: 'MD', name: 'Moldova', dialCode: '+373', maxLength: 8 },
        { code: 'MC', name: 'Monaco', dialCode: '+377', maxLength: 8 },
        { code: 'MN', name: 'Mongolia', dialCode: '+976', maxLength: 8 },
        { code: 'ME', name: 'Montenegro', dialCode: '+382', maxLength: 8 },
        { code: 'MS', name: 'Montserrat', dialCode: '+1664', maxLength: 7 },
        { code: 'MA', name: 'Morocco', dialCode: '+212', maxLength: 9 },
        { code: 'MZ', name: 'Mozambique', dialCode: '+258', maxLength: 9 },
        { code: 'MM', name: 'Myanmar', dialCode: '+95', maxLength: 9 },
        { code: 'NA', name: 'Namibia', dialCode: '+264', maxLength: 9 },
        { code: 'NR', name: 'Nauru', dialCode: '+674', maxLength: 7 },
        { code: 'NP', name: 'Nepal', dialCode: '+977', maxLength: 10 },
        { code: 'NL', name: 'Netherlands', dialCode: '+31', maxLength: 9 },
        { code: 'NC', name: 'New Caledonia', dialCode: '+687', maxLength: 6 },
        { code: 'NZ', name: 'New Zealand', dialCode: '+64', maxLength: 9 },
        { code: 'NI', name: 'Nicaragua', dialCode: '+505', maxLength: 8 },
        { code: 'NE', name: 'Niger', dialCode: '+227', maxLength: 8 },
        { code: 'NG', name: 'Nigeria', dialCode: '+234', maxLength: 10 },
        { code: 'NU', name: 'Niue', dialCode: '+683', maxLength: 4 },
        { code: 'NF', name: 'Norfolk Island', dialCode: '+672', maxLength: 6 },
        { code: 'KP', name: 'North Korea', dialCode: '+850', maxLength: 10 },
        { code: 'MP', name: 'Northern Mariana Islands', dialCode: '+1670', maxLength: 7 },
        { code: 'NO', name: 'Norway', dialCode: '+47', maxLength: 8 },
        { code: 'OM', name: 'Oman', dialCode: '+968', maxLength: 8 },
        { code: 'PK', name: 'Pakistan', dialCode: '+92', maxLength: 10 },
        { code: 'PW', name: 'Palau', dialCode: '+680', maxLength: 7 },
        { code: 'PS', name: 'Palestine', dialCode: '+970', maxLength: 9 },
        { code: 'PA', name: 'Panama', dialCode: '+507', maxLength: 8 },
        { code: 'PG', name: 'Papua New Guinea', dialCode: '+675', maxLength: 8 },
        { code: 'PY', name: 'Paraguay', dialCode: '+595', maxLength: 9 },
        { code: 'PE', name: 'Peru', dialCode: '+51', maxLength: 9 },
        { code: 'PH', name: 'Philippines', dialCode: '+63', maxLength: 10 },
        { code: 'PL', name: 'Poland', dialCode: '+48', maxLength: 9 },
        { code: 'PT', name: 'Portugal', dialCode: '+351', maxLength: 9 },
        { code: 'PR', name: 'Puerto Rico', dialCode: '+1787', maxLength: 10 },
        { code: 'QA', name: 'Qatar', dialCode: '+974', maxLength: 8 },
        { code: 'CG', name: 'Republic of the Congo', dialCode: '+242', maxLength: 9 },
        { code: 'RE', name: 'Reunion', dialCode: '+262', maxLength: 9 },
        { code: 'RO', name: 'Romania', dialCode: '+40', maxLength: 9 },
        { code: 'RU', name: 'Russia', dialCode: '+7', maxLength: 10 },
        { code: 'RW', name: 'Rwanda', dialCode: '+250', maxLength: 9 },
        { code: 'BL', name: 'Saint Barthelemy', dialCode: '+590', maxLength: 9 },
        { code: 'SH', name: 'Saint Helena', dialCode: '+290', maxLength: 4 },
        { code: 'KN', name: 'Saint Kitts and Nevis', dialCode: '+1869', maxLength: 7 },
        { code: 'LC', name: 'Saint Lucia', dialCode: '+1758', maxLength: 7 },
        { code: 'MF', name: 'Saint Martin', dialCode: '+590', maxLength: 9 },
        { code: 'PM', name: 'Saint Pierre and Miquelon', dialCode: '+508', maxLength: 6 },
        { code: 'VC', name: 'Saint Vincent and the Grenadines', dialCode: '+1784', maxLength: 7 },
        { code: 'WS', name: 'Samoa', dialCode: '+685', maxLength: 7 },
        { code: 'SM', name: 'San Marino', dialCode: '+378', maxLength: 10 },
        { code: 'ST', name: 'Sao Tome and Principe', dialCode: '+239', maxLength: 7 },
        { code: 'SA', name: 'Saudi Arabia', dialCode: '+966', maxLength: 9 },
        { code: 'SN', name: 'Senegal', dialCode: '+221', maxLength: 9 },
        { code: 'RS', name: 'Serbia', dialCode: '+381', maxLength: 9 },
        { code: 'SC', name: 'Seychelles', dialCode: '+248', maxLength: 7 },
        { code: 'SL', name: 'Sierra Leone', dialCode: '+232', maxLength: 8 },
        { code: 'SG', name: 'Singapore', dialCode: '+65', maxLength: 8 },
        { code: 'SX', name: 'Sint Maarten', dialCode: '+1721', maxLength: 7 },
        { code: 'SK', name: 'Slovakia', dialCode: '+421', maxLength: 9 },
        { code: 'SI', name: 'Slovenia', dialCode: '+386', maxLength: 8 },
        { code: 'SB', name: 'Solomon Islands', dialCode: '+677', maxLength: 7 },
        { code: 'SO', name: 'Somalia', dialCode: '+252', maxLength: 8 },
        { code: 'ZA', name: 'South Africa', dialCode: '+27', maxLength: 9 },
        { code: 'KR', name: 'South Korea', dialCode: '+82', maxLength: 10 },
        { code: 'SS', name: 'South Sudan', dialCode: '+211', maxLength: 9 },
        { code: 'ES', name: 'Spain', dialCode: '+34', maxLength: 9 },
        { code: 'LK', name: 'Sri Lanka', dialCode: '+94', maxLength: 9 },
        { code: 'SD', name: 'Sudan', dialCode: '+249', maxLength: 9 },
        { code: 'SR', name: 'Suriname', dialCode: '+597', maxLength: 7 },
        { code: 'SJ', name: 'Svalbard and Jan Mayen', dialCode: '+47', maxLength: 8 },
        { code: 'SZ', name: 'Swaziland', dialCode: '+268', maxLength: 8 },
        { code: 'SE', name: 'Sweden', dialCode: '+46', maxLength: 9 },
        { code: 'CH', name: 'Switzerland', dialCode: '+41', maxLength: 9 },
        { code: 'SY', name: 'Syria', dialCode: '+963', maxLength: 9 },
        { code: 'TW', name: 'Taiwan', dialCode: '+886', maxLength: 9 },
        { code: 'TJ', name: 'Tajikistan', dialCode: '+992', maxLength: 9 },
        { code: 'TZ', name: 'Tanzania', dialCode: '+255', maxLength: 9 },
        { code: 'TH', name: 'Thailand', dialCode: '+66', maxLength: 9 },
        { code: 'TL', name: 'Timor-Leste', dialCode: '+670', maxLength: 8 },
        { code: 'TG', name: 'Togo', dialCode: '+228', maxLength: 8 },
        { code: 'TK', name: 'Tokelau', dialCode: '+690', maxLength: 4 },
        { code: 'TO', name: 'Tonga', dialCode: '+676', maxLength: 7 },
        { code: 'TT', name: 'Trinidad and Tobago', dialCode: '+1868', maxLength: 7 },
        { code: 'TN', name: 'Tunisia', dialCode: '+216', maxLength: 8 },
        { code: 'TR', name: 'Turkey', dialCode: '+90', maxLength: 10 },
        { code: 'TM', name: 'Turkmenistan', dialCode: '+993', maxLength: 8 },
        { code: 'TC', name: 'Turks and Caicos Islands', dialCode: '+1649', maxLength: 7 },
        { code: 'TV', name: 'Tuvalu', dialCode: '+688', maxLength: 5 },
        { code: 'VI', name: 'U.S. Virgin Islands', dialCode: '+1340', maxLength: 7 },
        { code: 'UG', name: 'Uganda', dialCode: '+256', maxLength: 9 },
        { code: 'UA', name: 'Ukraine', dialCode: '+380', maxLength: 9 },
        { code: 'AE', name: 'United Arab Emirates', dialCode: '+971', maxLength: 9 },
        { code: 'GB', name: 'United Kingdom', dialCode: '+44', maxLength: 10 },
        { code: 'US', name: 'United States', dialCode: '+1', maxLength: 10 },
        { code: 'UY', name: 'Uruguay', dialCode: '+598', maxLength: 8 },
        { code: 'UZ', name: 'Uzbekistan', dialCode: '+998', maxLength: 9 },
        { code: 'VU', name: 'Vanuatu', dialCode: '+678', maxLength: 7 },
        { code: 'VA', name: 'Vatican', dialCode: '+39', maxLength: 10 },
        { code: 'VE', name: 'Venezuela', dialCode: '+58', maxLength: 10 },
        { code: 'VN', name: 'Vietnam', dialCode: '+84', maxLength: 10 },
        { code: 'WF', name: 'Wallis and Futuna', dialCode: '+681', maxLength: 6 },
        { code: 'EH', name: 'Western Sahara', dialCode: '+212', maxLength: 9 },
        { code: 'YE', name: 'Yemen', dialCode: '+967', maxLength: 9 },
        { code: 'ZM', name: 'Zambia', dialCode: '+260', maxLength: 9 },
        { code: 'ZW', name: 'Zimbabwe', dialCode: '+263', maxLength: 9 }
    ];

    /**
     * Initialize WhatsApp number inputs
     */
    function initWhatsAppNumberFields() {
        // Find all WhatsApp button elements
        $('.fcb-button-type').each(function() {
            if ($(this).val() === 'whatsapp') {
                const valueInput = $(this).closest('.fcb-button-content').find('.fcb-button-value');
                if (!valueInput.hasClass('whatsapp-enabled')) {
                    setupWhatsAppInput(valueInput);
                }
            }
        });

        // Listen for button type changes
        $(document).on('change', '.fcb-button-type', function() {
            const valueInput = $(this).closest('.fcb-button-content').find('.fcb-button-value');
            const valueLabel = $(this).closest('.fcb-button-content').find('.fcb-value-label');
            
            // If changing to WhatsApp
            if ($(this).val() === 'whatsapp') {
                if (!valueInput.hasClass('whatsapp-enabled')) {
                    // Hide the original label since we'll add our own
                    valueLabel.hide();
                    setupWhatsAppInput(valueInput);
                }
            } 
            // If changing from WhatsApp to something else
            else if (valueInput.hasClass('whatsapp-enabled')) {
                // Get the actual value (without country code)
                const number = valueInput.data('phone-number') || '';
                
                // Remove all custom elements
                valueInput.parent().find('.whatsapp-custom-ui, .whatsapp-validation-message').remove();
                
                // Reset the input
                valueInput.removeClass('whatsapp-enabled valid-phone invalid-phone');
                valueInput.val(number);
                valueInput.removeData('selected-country');
                valueInput.removeData('phone-number');
                valueInput.css('display', '');
                valueInput.prop('readonly', false);
                
                // Show the original label
                valueLabel.show();
            }
        });

        // Also handle new buttons being added
        $(document).on('fcb:buttonAdded', function(e, buttonElement) {
            const buttonType = $(buttonElement).find('.fcb-button-type');
            if (buttonType.val() === 'whatsapp') {
                const valueInput = $(buttonElement).find('.fcb-button-value');
                const valueLabel = $(buttonElement).find('.fcb-value-label');
                if (!valueInput.hasClass('whatsapp-enabled')) {
                    valueLabel.hide();
                    setupWhatsAppInput(valueInput);
                }
            }
        });
    }

    /**
     * Setup WhatsApp input field with country selection
     */
    function setupWhatsAppInput(inputElement) {
        // Mark as enabled
        inputElement.addClass('whatsapp-enabled');
        
        // Hide the original input completely (we'll use it to store data)
        inputElement.css('display', 'none');
        
        // Create custom UI container
        const customUI = $('<div class="whatsapp-custom-ui"></div>');
        inputElement.before(customUI);
        
        // Create country selection section
        const countrySection = $(`
            <div class="whatsapp-country-section">
                <label class="whatsapp-section-label">WhatsApp Number:</label>
                <div class="whatsapp-country-selector-wrapper">
                    <div class="whatsapp-selected-country">
                        <div class="whatsapp-flag"></div>
                        <div class="whatsapp-country-name">Select a country</div>
                        <div class="whatsapp-country-code"></div>
                        <div class="whatsapp-dropdown-arrow">▼</div>
                    </div>
                    <div class="whatsapp-country-dropdown">
                        <div class="whatsapp-search-container">
                            <input type="text" class="whatsapp-country-search" placeholder="Search country...">
                        </div>
                        <div class="whatsapp-country-list"></div>
                    </div>
                </div>
            </div>
        `);
        customUI.append(countrySection);
        
        // Create phone number input section
        const phoneSection = $(`
            <div class="whatsapp-phone-section">
                <input type="tel" class="whatsapp-phone-input" placeholder="Enter phone number without country code" disabled>
                <div class="whatsapp-validation-message"></div>
            </div>
        `);
        customUI.append(phoneSection);
        
        // Populate country list
        const countryList = customUI.find('.whatsapp-country-list');
        countries.forEach(country => {
            countryList.append(`
                <div class="whatsapp-country-item" data-country-code="${country.code}" 
                     data-dial-code="${country.dialCode}" data-max-length="${country.maxLength}">
                    <div class="whatsapp-flag whatsapp-flag-${country.code.toLowerCase()}"></div>
                    <div class="whatsapp-country-name">${country.name}</div>
                    <div class="whatsapp-country-dial-code">${country.dialCode}</div>
                </div>
            `);
        });
        
        // Get references to elements
        const $selectedCountry = customUI.find('.whatsapp-selected-country');
        const $countryDropdown = customUI.find('.whatsapp-country-dropdown');
        const $searchInput = customUI.find('.whatsapp-country-search');
        const $phoneInput = customUI.find('.whatsapp-phone-input');
        const $countryItems = customUI.find('.whatsapp-country-item');
        const $validationMessage = customUI.find('.whatsapp-validation-message');
        
        // Load flag CSS if not already loaded
        if (!$('link[href*="country-flags"]').length) {
            $('head').append('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.5.0/css/flag-icon.min.css">');
            
            // Add inline styles for flag icons
            $('head').append(`
                <style>
                    .whatsapp-flag {
                        display: inline-block;
                        width: 24px;
                        height: 16px;
                        background-size: cover;
                        margin-right: 8px;
                    }
                    
                    ${countries.map(country => 
                        `.whatsapp-flag-${country.code.toLowerCase()} { 
                            background-image: url('https://catamphetamine.gitlab.io/country-flag-icons/3x2/${country.code}.svg');
                        }`
                    ).join('\n')}
                </style>
            `);
        }
        
        // Toggle dropdown on click
        $selectedCountry.on('click', function() {
            $countryDropdown.toggleClass('open');
            if ($countryDropdown.hasClass('open')) {
                $searchInput.focus();
                // Show all countries by default when opened
                $countryItems.show();
                // Clear any previous search
                $searchInput.val('');
            }
        });
        
        // Close dropdown when clicking outside
        $(document).on('click', function(event) {
            if (!$(event.target).closest('.whatsapp-country-selector-wrapper').length) {
                $countryDropdown.removeClass('open');
            }
        });
        
        // Search functionality
        $searchInput.on('input', function() {
            const searchTerm = $(this).val().toLowerCase();
            
            $countryItems.each(function() {
                const countryName = $(this).find('.whatsapp-country-name').text().toLowerCase();
                if (countryName.includes(searchTerm)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
        
        // Select country
        $countryItems.on('click', function() {
            const countryCode = $(this).data('country-code');
            const dialCode = $(this).data('dial-code');
            const maxLength = $(this).data('max-length');
            const countryName = $(this).find('.whatsapp-country-name').text();
            
            // Update selected country display
            $selectedCountry.find('.whatsapp-flag').attr('class', `whatsapp-flag whatsapp-flag-${countryCode.toLowerCase()}`);
            $selectedCountry.find('.whatsapp-country-name').text(countryName);
            $selectedCountry.find('.whatsapp-country-code').text(dialCode);
            
            // Store country info
            inputElement.data('selected-country', {
                code: countryCode,
                dialCode: dialCode,
                maxLength: maxLength,
                name: countryName
            });
            
            // Enable phone input
            $phoneInput.prop('disabled', false);
            $phoneInput.attr('maxlength', maxLength);
            $phoneInput.attr('placeholder', `Enter phone number (max ${maxLength} digits)`);
            
            // Update validation
            validatePhone($phoneInput.val(), maxLength, $phoneInput, $validationMessage, inputElement);
            
            // Close dropdown
            $countryDropdown.removeClass('open');
        });
        
        // Phone input validation
        $phoneInput.on('input', function(e) {
            const selectedCountry = inputElement.data('selected-country');
            if (!selectedCountry) return;
            
            // Allow only numbers
            let value = $(this).val().replace(/\D/g, '');
            $(this).val(value);
            
            // Enforce max length
            if (value.length > selectedCountry.maxLength) {
                value = value.substring(0, selectedCountry.maxLength);
                $(this).val(value);
            }
            
            // Validate
            validatePhone(value, selectedCountry.maxLength, $(this), $validationMessage, inputElement);
        });
        
        // Check for existing value and try to parse it
        if (inputElement.val()) {
            parseExistingNumber(inputElement.val(), inputElement, customUI);
        }
    }
    
    /**
     * Validate phone number
     */
    function validatePhone(phoneNumber, maxLength, phoneInput, validationMessage, originalInput) {
        const selectedCountry = originalInput.data('selected-country');
        if (!selectedCountry) return;
        
        if (!phoneNumber) {
            validationMessage.text('Please enter a phone number').addClass('error').show();
            phoneInput.removeClass('valid-phone').addClass('invalid-phone');
            originalInput.val('');
            originalInput.data('phone-number', '');
            return false;
        }
        
        // Basic length validation
        if (phoneNumber.length < 5) {
            validationMessage.text('Number is too short').addClass('error').show();
            phoneInput.removeClass('valid-phone').addClass('invalid-phone');
            originalInput.val('');
            originalInput.data('phone-number', phoneNumber);
            return false;
        }
        
        if (phoneNumber.length > maxLength) {
            validationMessage.text(`Maximum ${maxLength} digits allowed`).addClass('error').show();
            phoneInput.removeClass('valid-phone').addClass('invalid-phone');
            originalInput.val('');
            originalInput.data('phone-number', phoneNumber);
            return false;
        }
        
        // Valid
        validationMessage.text('Valid number format').removeClass('error').addClass('success').show();
        phoneInput.removeClass('invalid-phone').addClass('valid-phone');
        
        // Remove any '+' character from dial code
        const cleanDialCode = selectedCountry.dialCode.replace('+', '');
        
        // Store the full number in the original input (for WhatsApp it should be without the '+')
        originalInput.val(cleanDialCode + phoneNumber);
        originalInput.data('phone-number', phoneNumber);
        
        return true;
    }
    
    /**
     * Parse existing phone number
     */
    function parseExistingNumber(fullNumber, originalInput, customUI) {
        // Find possible country match
        fullNumber = fullNumber.replace(/[^0-9]/g, ''); // Remove non-digits
        
        // Try to find the country by checking different dial code lengths
        let matchedCountry = null;
        let matchedPhoneNumber = '';
        
        // Sort countries by dial code length (longest first) to avoid wrong matches
        const sortedCountries = [...countries].sort((a, b) => {
            return b.dialCode.replace('+', '').length - a.dialCode.replace('+', '').length;
        });
        
        for (const country of sortedCountries) {
            const dialCode = country.dialCode.replace('+', '');
            if (fullNumber.startsWith(dialCode)) {
                matchedCountry = country;
                matchedPhoneNumber = fullNumber.substring(dialCode.length);
                break;
            }
        }
        
        if (matchedCountry) {
            // Update UI
            const $selectedCountry = customUI.find('.whatsapp-selected-country');
            $selectedCountry.find('.whatsapp-flag').attr('class', `whatsapp-flag whatsapp-flag-${matchedCountry.code.toLowerCase()}`);
            $selectedCountry.find('.whatsapp-country-name').text(matchedCountry.name);
            $selectedCountry.find('.whatsapp-country-code').text(matchedCountry.dialCode);
            
            // Store country info
            originalInput.data('selected-country', {
                code: matchedCountry.code,
                dialCode: matchedCountry.dialCode,
                maxLength: matchedCountry.maxLength,
                name: matchedCountry.name
            });
            
            // Set phone number
            const $phoneInput = customUI.find('.whatsapp-phone-input');
            $phoneInput.prop('disabled', false);
            $phoneInput.val(matchedPhoneNumber);
            $phoneInput.attr('maxlength', matchedCountry.maxLength);
            $phoneInput.attr('placeholder', `Enter phone number (max ${matchedCountry.maxLength} digits)`);
            
            // Validate
            const $validationMessage = customUI.find('.whatsapp-validation-message');
            validatePhone(matchedPhoneNumber, matchedCountry.maxLength, $phoneInput, $validationMessage, originalInput);
        }
    }

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        // Only run on the plugin's admin page
        if ($('body.floating-contact-button_page_floating-contact-button').length || 
            $('body.toplevel_page_floating-contact-button').length) {
            initWhatsAppNumberFields();
        }
    });
    
})(jQuery);