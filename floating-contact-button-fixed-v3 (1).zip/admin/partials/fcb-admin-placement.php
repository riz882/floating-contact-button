<?php
/**
 * Placement tab
 *
 * @package    Floating_Contact_Button
 * @subpackage Floating_Contact_Button/admin/partials
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Get placement settings
$placement = get_option('fcb_placement', array(
    'position' => 'bottom-right',
    'visibility' => 'all',
    'specific_pages' => array(),
    'spacing' => '20',
));
?>

<div class="fcb-columns">
    <div class="fcb-column fcb-column-70">
        <div class="fcb-section-title">
            <h3><?php _e('Button Placement Settings', 'floating-contact-button'); ?></h3>
            <p><?php _e('Configure where and when to display the floating contact buttons.', 'floating-contact-button'); ?></p>
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_position"><?php _e('Position:', 'floating-contact-button'); ?></label>
            <select name="fcb_position" id="fcb_position">
                <option value="bottom-right" <?php selected($placement['position'], 'bottom-right'); ?>><?php _e('Bottom Right', 'floating-contact-button'); ?></option>
                <option value="bottom-left" <?php selected($placement['position'], 'bottom-left'); ?>><?php _e('Bottom Left', 'floating-contact-button'); ?></option>
                <option value="bottom-center" <?php selected($placement['position'], 'bottom-center'); ?>><?php _e('Bottom Center', 'floating-contact-button'); ?></option>
                <option value="middle-right" <?php selected($placement['position'], 'middle-right'); ?>><?php _e('Middle Right', 'floating-contact-button'); ?></option>
                <option value="middle-left" <?php selected($placement['position'], 'middle-left'); ?>><?php _e('Middle Left', 'floating-contact-button'); ?></option>
                <option value="top-right" <?php selected($placement['position'], 'top-right'); ?>><?php _e('Top Right', 'floating-contact-button'); ?></option>
                <option value="top-left" <?php selected($placement['position'], 'top-left'); ?>><?php _e('Top Left', 'floating-contact-button'); ?></option>
                <option value="top-center" <?php selected($placement['position'], 'top-center'); ?>><?php _e('Top Center', 'floating-contact-button'); ?></option>
            </select>
        </div>
        
        <div class="fcb-form-row">
            <label for="fcb_visibility"><?php _e('Visibility:', 'floating-contact-button'); ?></label>
            <select name="fcb_visibility" id="fcb_visibility">
                <option value="all" <?php selected($placement['visibility'], 'all'); ?>><?php _e('All pages', 'floating-contact-button'); ?></option>
                <option value="homepage" <?php selected($placement['visibility'], 'homepage'); ?>><?php _e('Homepage only', 'floating-contact-button'); ?></option>
                <option value="specific" <?php selected($placement['visibility'], 'specific'); ?>><?php _e('Specific pages', 'floating-contact-button'); ?></option>
            </select>
        </div>
        
        <div class="fcb-form-row" id="fcb_specific_pages_container" style="<?php echo $placement['visibility'] == 'specific' ? 'display:block;' : 'display:none;'; ?>">
            <label><?php _e('Select Pages/Posts:', 'floating-contact-button'); ?></label>
            <div class="fcb-page-selector">
                <?php
                // Get all published pages and posts
                $args = array(
                    'post_type' => array('page', 'post'),
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                    'orderby' => 'title',
                    'order' => 'ASC',
                );
                
                $pages = get_posts($args);
                
                foreach ($pages as $page) :
                    $checked = in_array($page->ID, $placement['specific_pages']) ? 'checked="checked"' : '';
                ?>
                    <label>
                        <input type="checkbox" name="fcb_specific_pages[]" value="<?php echo esc_attr($page->ID); ?>" <?php echo $checked; ?>>
                        <?php echo esc_html($page->post_title); ?> (<?php echo get_post_type($page->ID); ?>)
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="fcb-form-row fcb-form-row-spacing">
            <label for="fcb_spacing"><?php _e('Spacing from Edge (px):', 'floating-contact-button'); ?></label>
            <div class="fcb-spacing-control-wrapper">
                <input type="number" name="fcb_spacing" id="fcb_spacing" value="<?php echo esc_attr($placement['spacing']); ?>" min="0" max="100" class="fcb-spacing-number-input">
                <div class="fcb-slider-container">
                    <div class="fcb-spacing-slider"></div>
                    <div class="fcb-slider-value"><?php echo esc_attr($placement['spacing']); ?>px</div>
                </div>
            </div>
        </div>
        
        <script>
            jQuery(document).ready(function($) {
                // Toggle specific pages container
                $('#fcb_visibility').on('change', function() {
                    if ($(this).val() === 'specific') {
                        $('#fcb_specific_pages_container').show();
                    } else {
                        $('#fcb_specific_pages_container').hide();
                    }
                });
            });
        </script>
    </div>
    
    <div class="fcb-column fcb-column-30">
        <div class="fcb-preview-container">
            <h3><?php _e('Live Preview', 'floating-contact-button'); ?></h3>
            <div class="fcb-live-preview"></div>
            <p class="description"><?php _e('This is a preview of how your buttons will appear on your website.', 'floating-contact-button'); ?></p>
        </div>
    </div>
</div>
